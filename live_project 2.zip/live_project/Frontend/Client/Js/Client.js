async function o() {
    console.log("click");
    try {
        let y = JSON.parse(window.sessionStorage.getItem("Client"))
        const response = await fetch(`http://localhost:9090/fetchAceptClient?id=${y.id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
            }
        })
        let table = document.getElementById("pop_up");
        if (response.status == 302) {
            let responses = await response.json()
            let w = responses.data
            let pre = ""
            w.map(async(data)=>{
                if(data.status!=null){
                    let entrydate=new Date(data.entryDate)
                entrydate=entrydate.getDate()+"/"+(entrydate.getMonth()+1)+"/"+entrydate.getFullYear()
                let exitdate=new Date(data.exitDate)
                exitdate=exitdate.getDate()+"/"+(exitdate.getMonth()+1)+"/"+exitdate.getFullYear()
                    table.style.display = "block"
                    if(data.status=="ok"){
                   
                    if (data.payment == "CASH") {
                        if (data.admin_id != 0) {
                            pre += `<pre>You  booking is confrom from <span>${data.admin_id}</span>
                            workspace <span>${data.workSpace.type}</span>
                            from <span>${entrydate}</span> to <span>${exitdate}</span>
                            the payment cost is <span>${data.payment}</span><br>
                            `
                        }
                        else if (data.manager_id != 0) {
                            pre += `<pre>You  booking is confrom from <span>${data.manager_id}</span>
                                for workspace <span>${data.workSpace.type}</span>
                                from <span>${entrydate}</span> to <span>${exitdate}</span>
                                the payment cost is <span>${data.payment}</span> <br>
                                `
                        }
                        let clientBooking = {
                            "entryDate": data.entryDate,
                            "exitDate": data.exitDate,
                            "cost": data.cost,
                            "payment": data.payment
                        }
                        try {
                            const response = await fetch(`http://localhost:9090/addBooking?workSpace_id=${data.workSpace.id}&client_id=${y.id}&type=${data.workSpace.type}`,
                                {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json",
                                    },
                                    body: JSON.stringify(clientBooking)
                                });
                            const res = await fetch(`http://localhost:9090/deleteAcept?id=${data.booking_id}`, {
                                method: "DELETE",
                                headers: {
                                    "Content-Type": "application/json",
                                }
                            })
                            console.log(res)
                        } catch (error) {
                            alert(error)
                        }
                    }
                    else {
                        if (data.admin_id != 0) {
                            pre += `<pre>You  booking is confrom from <span>${data.admin_id}</span>
                        workspace <span>${data.workSpace.type}</span>
                        from <span>${entrydate}</span> to <span>${exitdate}</span>
                        the payment cost is <span>${data.payment}</span> <br>
                        <button onclick="accepted(${data.booking_id})">accepted</button>  <button onclick="reject(${data.booking_id})">reject</button></pre><br>`
                        }
                        else if (data.manager_id != 0) {
                            console.log(data.manager_id);
                            pre += `<pre>You  booking is confrom from <span>${data.manager_id}</span>
                            for workspace <span>${data.workSpace.type}</span>
                            from <span>${entrydate}</span> to <span>${exitdate}</span>
                            the payment cost is <span>${data.payment}</span> <br>
                            <button onclick="accepted(${data.booking_id})">accepted</button>  <button onclick="reject(${data.booking_id})">reject</button></pre><br>`
                        }
                    }
                }
                else {
                    if(data.admin_id!=0){
                        pre+=`<pre>You  booking is reject from <span>${data.admin_id}</span>
                    for workspace <span>${data.workSpace.type}</span>
                    from <span>${entrydate}</span> to <span>${exitdate}</span><br>
                    `}
                    else if(data.manager_id!=0){
                        pre+=`<pre>You  booking is reject from <span>${data.manager_id}</span>
                        for workspace <span>${data.workSpace.type}</span>
                        from <span>${entrydate}</span> to <span>${exitdate}</span><br>
                        `}
                    const response=await fetch(`http://localhost:9090/deleteAcept?id=${data.booking_id}`,{
                        method: "DELETE",
                        headers: {
                        "Content-Type": "application/json",
                      }
                    }) 
                    // console.log(response)
                }
            }
            })
            
            pre += `<br><button id="Back"  onclick="back()">Back</button>`
            table.innerHTML = pre
        }
        else if (response.status == 404) {
            alert("no bookings")
        }
        else {
            table.style.display = "none"
        }
    } catch (error) {
        alert(error)
    }
}
function back(){
    let table = document.getElementById("pop_up");
    table.style.display = "none"
}
async function accepted(id) {
    let card = document.getElementById("card")
    card.style.display = "block"
    Submit.addEventListener("click",async(e)=>{
        e.preventDefault()
        let a= await fetch(`http://localhost:9090/fetchCard?card=${card_no.value}&cvv=${cvv.value}`)
        if (a.status == 302) {
            f1(id)
            card.style.display = "none"
        }
        else {
            alert("Invaild data \ntry again")
            accepted(id)
        }
    })
}
async function f1(id) {
    const response=await fetch(`http://localhost:9090/fetchAceptById?id=${id}`)
    let z= await response.json()
    let y=JSON.parse(window.sessionStorage.getItem("Client"))
    if(response.status==302){
        let input=z.data
        console.log(z)
        let genrateotp;
        function genrate() {
        let a = Math.round(Math.random() * 10000)
        if (a > 999 & a < 10000) {
            genrateotp = a
            console.log(genrateotp)
        }
        else {
            genrate()
        }
    }
    genrate()
    let otp = prompt("Enter the otp :",)
    if (otp == genrateotp) {
        let clientBooking = {
            "entryDate": input.entryDate,
            "exitDate": input.exitDate,
            "cost": input.cost,
            "payment": input.payment
        }
        try {
            const response = await fetch(`http://localhost:9090/addBooking?workSpace_id=${input.workSpace.id}&client_id=${y.id}&type=${input.workSpace.type}`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(clientBooking)
                });
            const res = await fetch(`http://localhost:9090/deleteAcept?id=${id}`, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                }
            })
        } catch (error) {
            alert(error)
        }
    }
    else if(otp == "") {
        let card = document.getElementById("card")
    card.style.display = "none"
        return
    }
    else {
        alert("invaild otp")
        f1(id)
    }
}
else{
    alert(y.data)
}
o()
}
async function reject(id){
    try{
        const res = await fetch(`http://localhost:9090/deleteAcept?id=${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            }
        })  
    }
    catch{
        alert(error)
    }
}
update.addEventListener("click", (e) => {
    e.preventDefault()
    window.open(URL = "http://127.0.0.1:5500/Client/Html/Update.html", "_self")
})
logout.addEventListener("click",async()=>{
    window.sessionStorage.clear()
    window.open(URL="http://127.0.0.1:5500/index.html","_self");
})
Delete.addEventListener("click", async (e) => {
    let y = JSON.parse(window.sessionStorage.getItem("Client"))
    e.preventDefault()
    try {
        const response = await fetch(`http://localhost:9090/deleteClient?client_id=${y.id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            }
        })
        console.log(response)
        if (response.status == 201) {
            alert("Account delete successfully");
            window.open(URL = "http://127.0.0.1:5500/Client/Html/Login.html", "_self");
            window.sessionStorage.removeItem("admin")
        }
        else if (response.ok) {
            alert("Sorry  Account not found");
        }
        else {
            alert("Account not delete successfully");
        }
    } catch (error) {
        window.alert(error)
    }
}, false)

Fetch.addEventListener("click", () => {
    window.open(URL = "http://127.0.0.1:5500/Client/Html/Profile.html", "_self");
})
addBooking.addEventListener("click", async () => {
    try {
        const response = await fetch(`http://localhost:9090/findCity`)
        let x = await response.json();
        // console.log(x.data); 
        window.sessionStorage.setItem("Citys", JSON.stringify(x.data))
        // window.sessionStorage.setItem("Buliding",JSON.stringify(x.data))
        window.open(URL = "http://127.0.0.1:5500/Client/Html/AddBooking1.html", "_self");
        // window.open(URL="http://127.0.0.1:5500/Client/Html/AddBooking.html","_self");
    } catch (error) {
        console.log(error)
    }
})
showBooking.addEventListener("click", async () => {
    try {
        let y=JSON.parse(window.sessionStorage.getItem("Client"))
        let x=y.bookings;
        window.sessionStorage.setItem("booking", JSON.stringify(x))
        window.open(URL="http://127.0.0.1:5500/Client/Html/ShowBooking.html","_self"); 
} catch (error) {
    console.log(error)
}
})