Sign_up.addEventListener("click",()=>{
    window.open("http://127.0.0.1:5500/Client/Html/Register.html")
})
login.addEventListener("click",async (e)=>{
    e.preventDefault();
    try {
        const response= await  fetch(`http://localhost:9090/clientLogin?email=${user.value}&password=${password.value}`)
        let x = await response.json();
        if(response.status==302){
            window.sessionStorage.setItem("Client",JSON.stringify(x.data))
            window.open(URL="http://127.0.0.1:5500/Client/Html/Client.html","_self");
        }
        else{
            alert(x.data)
        }

    } catch (error) {
        window.alert(error)
    }
},false)