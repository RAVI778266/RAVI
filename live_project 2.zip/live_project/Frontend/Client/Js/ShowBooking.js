function update(){
    let y=JSON.parse(window.sessionStorage.getItem("booking"))
        let tablebody=document.getElementById("tbody");
        let str="";
            y.map((data)=>{ 
                let entrydate=new Date(data.entryDate)
                entrydate=entrydate.getDate()+"/"+(entrydate.getMonth()+1)+"/"+entrydate.getFullYear()
                let exitdate=new Date(data.exitDate)
                exitdate=exitdate.getDate()+"/"+(exitdate.getMonth()+1)+"/"+exitdate.getFullYear()
                str+=`<tr>
                <th scope="row" class="id">${data.booking_id}</th>
                <td class="entryDate">${entrydate}</td>
                <td class="exitDate">${exitdate}</td>
                <td class="cost">${data.cost}</td>
                <td class="payment">${data.payment}</td>
                </tr>`                 
            })
            tablebody.innerHTML=str;
}
update();