function update(){
    let y=JSON.parse(window.sessionStorage.getItem("Buliding"))
        let tablebody=document.getElementById("tbody");
        let str="";
        y.map((data)=>{ 
            if(data.ratings==0){
                data.ratings="new";
            }
            // console.log(data.floors.length);
            if(data.manager!=null){
                str+=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="Name">${data.building_name}</td>
                <td class="ratings">${data.ratings}</td>
                <td class="manager">${data.manager.name}</td>
                <td class="address">${data.address.door_No},${data.address.street},<br>${data.address.landmark},,<br>${data.address.city},${data.address.district},<br>${data.address.state}.<br>${data.address.pincode}</td>
                <td class="manager">${data.floors.length}</td>
                <td><button class="button"  onclick="workSpace(${data.id},${data.manager.id})">Show WorkSpace</button></td>
                </tr>` 
            }
            else{
                str+=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="Name">${data.building_name}</td>
                <td class="ratings">${data.ratings}</td>
                <td class="manager">${data.admin.name}</td>
                <td class="address">${data.address.door_No},${data.address.street},<br>${data.address.landmark},<br>${data.address.city},${data.address.district},<br>${data.address.state}.<br>${data.address.pincode}</td>
                <td class="manager">${data.floors.length}</td>
                <td><button class="button"  onclick="workSpace1(${data.id},${data.admin.id})">Show WorkSpace</button></td>
                </tr>`
            }   
        })
        tablebody.innerHTML=str;
}
update();
async function workSpace(id,m_id){
  try {
    window.sessionStorage.removeItem("AdminId")
    const responses=await fetch(`http://localhost:9090/fetchWorkSpaceByBuilding?id=${id}`)
    let x=await responses.json();        
    // console.log(x.data)
    window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
    window.sessionStorage.setItem("ManagerId",m_id)
    window.open(URL="http://127.0.0.1:5500/Client/Html/AddWorkSpace1.html","_self");
  } catch (error) {
    console.log(error) 
  }
// update();
}
async function workSpace1(id,a_id){
  try {
    window.sessionStorage.removeItem("ManagerId")
    const responses=await fetch(`http://localhost:9090/fetchWorkSpaceByBuilding?id=${id}`)
    let x=await responses.json();        
    // console.log(x.data)
    window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
    window.sessionStorage.setItem("AdminId",a_id)
    window.open(URL="http://127.0.0.1:5500/Client/Html/AddWorkSpace1.html","_self");
  } catch (error) {
    console.log(error) 
  }
}