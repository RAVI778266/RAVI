Filter.addEventListener("click",async(e)=>{
    e.preventDefault();
    let price=document.getElementById("price").value
    let price1=document.getElementById("price1").value
    let type=document.getElementById("Workspace").value
    let capacity=document.getElementById("capacity").value
    let capacity1=document.getElementById("capacity1").value
    console.log(price,price1,type,capacity,capacity1);
    if(price=="" & price<=0){
        price=0.0
    }
    if(price1=="" & price1<=0){
        price1=99999.0
    }
    if(capacity=="" & capacity<=0){
        capacity=0
    }
    if(capacity1=="" & capacity1<=0){
        capacity1=99999
    }
    if(type!=""){
        try {
            console.log()
            const response=await fetch(`http://localhost:9090/filterWorkSpace?price=${price}&price1=${price1}&capacity=${capacity}&type=${type}&capacity1=${capacity1}`)
            let x=await response.json();  
            console.log(x.data); 
            window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
        } catch (error) {
            alert(error)
        }   
    }
    else{
        try {
            const response=await fetch(`http://localhost:9090/filterWorkSpacewithoutType?price=${price}&price1=${price1}&capacity=${capacity}&capacity1=${capacity1}`)
            let x=await response.json();  
            console.log(x.data); 
            window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
        } catch (error) {
            alert(error)
        }
    }
    /*try {
        const response=await fetch(`http://localhost:9090/filterWorkSpacewithoutType?price=${price}&price1=${price1}&type=${type}&capacity=${capacity}&capacity1=${capacity1}`)
        let x=await response.json();  
        console.log(x.data); 
        window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
    } catch (error) {
        alert(error)
    }*/
    update();
})

function update(){
    let y=JSON.parse(window.sessionStorage.getItem("workspaces"))
        let tablebody=document.getElementById("tbody");
        let str="";
        y.map((data)=>{ 
            // console.log(data);
            if(data.availability!='NOT FREE'){
                str+=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="capacity">${data.capacity}</td>
                <td class="type">${data.type}</td>
                <td class="pricePerDay">${data.pricePerDay}</td>
                <td class="availability">${data.availability}</td>
                <td class="squarefeet">${data.squarefeet}</td>
                <td><button class="button"  onclick="AddWorkSpace(${data.id})">AddWorkspace</button></td>
                </tr>` 
            }                
        })
        tablebody.innerHTML=str;
    }
update();
async function AddWorkSpace(id) {
    const response=await fetch(`http://localhost:9090/fetchWorkSpaceById?id=${id}`)
        let w=await response.json()
        window.sessionStorage.setItem("workspace",JSON.stringify(w.data));
        console.log(w)
        window.sessionStorage.setItem("date",new Date())
        console.log(window.sessionStorage.getItem("date"));
        window.open(URL="http://127.0.0.1:5500/Client/Html/AddClientBooking.html","_self")
}