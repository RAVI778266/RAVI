// let state=document.getElementById("state")
// // let state_name;
// // let district_name;
// // let city_name;
// // state.addEventListener("mouseenter",()=>{
//     window.fetch("/Indian_States_and_Districts.Json").then((data)=>data.json())
//     .then((res)=>{
//         res.map((data1)=> {
//         result=res
//           let opt=`<option>${data1.state_name}</option>`
//           state.innerHTML +=opt
//           console.log(state.value)
//         })
//     })
// // })
// let district=document.getElementById("district")
// district.addEventListener("mouseenter",()=>{
// window.fetch("/Indian_States_and_Districts.Json").then((data)=>data.json())
// .then((res)=>{
//     res.map((data1)=> {
//         data1.districts.map((data2)=>{
//             if(data1.state_name==state.value){
//                 let opt=`<option>${data2.district_name}</option>`
//                 district.innerHTML +=opt
//                 console.log(state.value)
//             }
//             else{
//                 console.log(state.value)
//                 district.innerHTML=`<option hidden>district</option>`
//             }
//         })
//     })
// })
// })








window.fetch("/Indian_States_and_Districts.Json").then((data)=>data.json())
    .then((res)=>{
        res.map((data1)=> {
          let opt=`<option>${data1.state_name}</option>`
          state.innerHTML +=opt
          data1.districts.map((data2)=>{
                let opt=`<option>${data2.district_name}</option>`
                district.innerHTML +=opt
        })
    })
})
let input=document.getElementsByTagName("input")
let p=document.getElementsByTagName("p");

password.addEventListener("keyup",()=>{
    let pwd= password.value
    let spl=/^(?=.*\W)^/
    let number=/^(?=.*\d)^/
    let upper=/^(?=.*[A-Z])^/
    let lower=/^(?=.*[a-z])^/
    let size=/(?=.*[a-z])(?=.*[A-Z]).{8,}/
    // const pattern = /^(?=.*\d)(?=.*[~`!@#$%^&*()--+={}\[\]|\\:;"'<>,.?/_₹])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    console.log(size.test(pwd))
    console.log(pwd)
    if(!upper.test(pwd)){
        p[0].innerText="should contain at least one upper case"
    }
    else if(!spl.test(pwd) ) {
        p[0].innerText="should contain at least one special characters"
    }
    else if(!number.test(pwd)){
        p[0].innerText="should contain at least one digit"
    }
    else if(!lower.test(pwd)){
        p[0].innerText="should contain at least one lower case"
    }
    else if(!size.test(pwd)){
        p[0].innerText="should contain at least 8 from the mentioned characters"
    }
    else{
        p[0].innerText="" 
    }
})
phone.addEventListener("keyup",()=>{
    let ph=/^[1-9]{1}[0-9]{9}$/
    let phno=phone.value
    console.log(ph.test(phno))
    if(!ph.test(phno)){
        p[1].innerText="should contain only 10 digit"
    }
    else{
        p[1].innerText=""
    } 
})
let check_gender=document.getElementsByName("gender")
signup.addEventListener('click', async (e) =>{
    e.preventDefault();
    for(let i=0;i<check_gender.length;i++){
        if(check_gender[i].checked){   
            gender=check_gender[i].value
        }
    }
    
    const client={
        "name":input[0].value,
        "email":input[1].value,
        "phone":input[4].value,
        "pwd":input[2].value,
        "gender":gender,
        "age":input[5].value,
        "id_proof":input[3].value,
        "address":{
            "door_No":input[9].value,
            "landmark":input[10].value,
            "street":input[11].value,
            "city":input[12].value,
            "state":state.value,
            "district":district.value,
            "pincode":input[13].value        
        }
    }
    try{
        const response = await fetch('http://localhost:9090/client',
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(client),
        });
        console.log(response.ok)
        if(response.ok){
          const data = await response.json();
          console.log(data);
          window.alert("Congratulations you have successfully created ");
          
          function save() {
            window.open(URL="http://127.0.0.1:5500/Client/Html/Login.html","_self");
          }
      
          save();
        }
        if (response.status >= 400) {
          window.alert("Youre Already Registered");
        }
    }
    catch(error){
      window.alert("error", error);
    }
})
