
signup.addEventListener('click', async (e) =>{
    e.preventDefault();
    let x=JSON.parse(window.sessionStorage.getItem("workspace"))
    let y=window.sessionStorage.getItem("ManagerId")
    let a=window.sessionStorage.getItem("AdminId")
    let z=JSON.parse(window.sessionStorage.getItem("Client"))
    let d=new Date(window.sessionStorage.getItem("date"))
    let entrydate=new Date(entryDate.value)
    let exitdate=new Date(exitDate.value)
    let cost=((exitdate.getTime()-entrydate.getTime())/(24*60*60*1000))*x.pricePerDay
    // console.log((exitdate.getTime()-entrydate.getTime())/(24*60*60*1000))
    // console.log(cost);
    if(entryDate.value!="" & (entrydate.getDate()-d.getDate())>0 & exitDate.value!="" & cost>0  & PAYMENT.value!=""){
        let clientBooking={
            "entryDate":entryDate.value,
            "exitDate":exitDate.value,
            "cost":cost,
            "payment":PAYMENT.value,
            "manager_id":y,
            "client_id":z.id,
            "admin_id":a,
            "workSpace":x
        }
        // console.log(clientBooking);        
    // window.sessionStorage.setItem("clientBooking",JSON.stringify(clientBooking))
    try {
        const response = await fetch(`http://localhost:9090/status`,{
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(clientBooking)
    });
        window.open(URL="http://127.0.0.1:5500/Client/Html/AddBooking.html","_self");
    } catch (error) {
        alert(error)
    }
    }
    else{
        alert("plz fill all details")
    }
    // console.log(new Date())
})