/************************update ***********************/
    function update(){
        let y=JSON.parse(window.sessionStorage.getItem("workspaces"))

            let tablebody=document.getElementById("tbody");
            let str="";
            y.map((data)=>{ 
                // console.log(data);
                if(data.availability!='NOT FREE'){
                    str+=`<tr>
                    <th scope="row" class="id">${data.id}</th>
                    <td class="capacity">${data.capacity}</td>
                    <td class="type">${data.type}</td>
                    <td class="pricePerDay">${data.pricePerDay}</td>
                    <td class="availability">${data.availability}</td>
                    <td class="squarefeet">${data.squarefeet}</td>
                    <td><button class="button"  onclick="AddWorkSpace(${data.id})">AddWorkspace</button></td>
                    </tr>` 
                }                
            })
            tablebody.innerHTML=str;
        }
    update();
    async function AddWorkSpace(id) {
        const response=await fetch(`http://localhost:9090/fetchWorkSpaceById?id=${id}`)
            let w=await response.json()
            window.sessionStorage.setItem("workspace",JSON.stringify(w.data));
            console.log(w)
            window.sessionStorage.setItem("date",new Date())
            console.log(window.sessionStorage.getItem("date"));
            window.open(URL="http://127.0.0.1:5500/Client/Html/AddClientBooking.html","_self");
       /* let y=JSON.parse(window.sessionStorage.getItem("Client"))
        let clientBooking={
            "entryDate":entryDate.value,
            "exitDate":exitDate.value,
            "cost":cost.value,
            "payment":payment.value
        }
        try {
            const response = await fetch(`http://localhost:9090/addBooking?workSpace_id=${id}&client_id=${y.id}&type=${type}`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(clientBooking)
        });
            window.open(URL="http://127.0.0.1:5500/Client/Html/AddBooking.html","_self");
        } catch (error) {
            alert(error)
        }*/
    }