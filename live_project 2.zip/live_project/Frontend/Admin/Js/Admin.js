async function o(){
    console.log("click");
    try {
        let y=JSON.parse(window.sessionStorage.getItem("admin"))
        const response=await fetch(`http://localhost:9090/fetchAceptAdmin?id=${y.id}`,{
            method: "GET",
            headers: {
            "Content-Type": "application/json",
          }
        })
        let table=document.getElementById("pop_up");
        if(response.status==302){
            let responses=await response.json()
            let w=responses.data
            let pre=""
            w.map(async(data)=>{
                table.style.display="block"
                if(data.status==null){
                    pre+=`<pre>You have get a booking  from <span>${client_id}</span>
                    workspace <span>${data.workspace.type}</span>
                    from <span>${data.entry_date}</span> to <span>${data.exit_date}</span>
                    the payment cost is <span>${data.payment}</span> <br>
                    <button onclick="accepted(${data})">accepted</button>  <button onclick="reject(${data})">reject</button></pre><br>`
                //     let text = "confrom the booking";
                //     if (confirm(text) == true) {
                //     text = "ok";
                // }
                // else {
                //     text = "canceled";
                // }
            }
        })
        pre=`<br><button id="Back"  onclick="back()">Back</button>`
        table.innerHTML=pre
    }
    else if (response.status==404){
        alert("no bookings")
    }
    else{
        table.style.display="none"
    }
    } catch (error) {
        alert(error)
    }
}
async function accepted(data){
    let text="ok"
    const x=await fetch(`http://localhost:9090/addStatus?status=${text}`,{
method: "PUT",
headers: {
    "Content-Type": "application/json",
},
body:JSON.stringify(data)
})
o();
}
async function reject(data){
    let text="canceled"
    const x=await fetch(`http://localhost:9090/addStatus?status=${text}`,{
method: "PUT",
headers: {
    "Content-Type": "application/json",
},
body:JSON.stringify(data)
})
o();
}
function back(){
    let table=document.getElementById("pop_up");
    table.style.display="none" 
}
update.addEventListener("click",(e)=>{
    e.preventDefault()
    window.open(URL="http://127.0.0.1:5500/Admin/Html/Update.html","_self")
})

Delete.addEventListener("click",async (e)=>{
    let y=JSON.parse(window.sessionStorage.getItem("admin"))
    e.preventDefault()  
    let text = "confrom you want to delete account";
    if (confirm(text) == true) { 
    try {
        const response=await fetch(`http://localhost:9090/deleteAdmin?id=${y.id}`,{
        method: "DELETE",
        headers: {
        "Content-Type": "application/json",
      }
    })
        if(response.status ==302){
            alert("Account delete successfully");
            window.open(URL="http://127.0.0.1:5500/Admin/Html/Login.html","_self");
            window.sessionStorage.removeItem("admin")
        }
        else if(response.status==404){
            alert("Sorry  Account not found");
        }
        else{
            alert("Account not delete successfully");
        }
    } catch (error) {
        window.alert(error)
    }
}
else {
    alert("Delete canceled successfully")
} 
},false)
logout.addEventListener("click",async()=>{
    window.sessionStorage.clear()
    window.open(URL="http://127.0.0.1:5500/index.html","_self");
})
Fetch.addEventListener("click",()=>{
    window.open(URL="http://127.0.0.1:5500/Admin/Html/Profile.html","_self");
})

addBuliding.addEventListener("click",()=>{
    window.open(URL="http://127.0.0.1:5500/Admin/Html/AddBuilding.html","_self");
})
showBuilding.addEventListener("click",async()=>{
    let y=JSON.parse(window.sessionStorage.getItem("admin"))
    try {
        const response=await fetch(`http://localhost:9090/fetchBuildingByadmin?id=${y.id}`)
        let x=await response.json();        
        window.sessionStorage.setItem("Buliding",JSON.stringify(x.data))
    } catch (error) {
        console.log(error)
    }
    // let z=JSON.parse(window.sessionStorage.getItem("Buliding"))
    // console.log(z);
    window.open(URL="http://127.0.0.1:5500/Admin/Html/ShowBuilding.html","_self");
},false)