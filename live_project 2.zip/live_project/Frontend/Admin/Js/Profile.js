const img = document.querySelector("img");
const icons = document.querySelector(".icons");
let y=JSON.parse(window.sessionStorage.getItem("admin"))
img.onclick = function(){
    this.classList.toggle("active");
    icons.classList.toggle("active");
}
Name.innerText=y.name
email.innerText=y.email
phone.innerText=y.phone
Address.addEventListener("click",()=>{
    container.style.height="570px"
    display.innerHTML=`${y.address.door_No},${y.address.landmark},${y.address.street}<br>${y.address.city},${y.address.pincode}<br>${y.address.district}<br>${y.address.state}.`
})
container.addEventListener("mouseout",()=>{
    container.style.height="250px"
})
container.addEventListener("mouseover",()=>{
    display.innerHTML=""
    container.style.height="470px"
})
back.addEventListener("click",()=>{
    window.open(URL="http://127.0.0.1:5500/Admin/Html/Admin.html","_self");
})