window.fetch("/Indian_States_and_Districts.Json").then((data)=>data.json())
    .then((res)=>{
        res.map((data1)=> {
          let opt=`<option>${data1.state_name}</option>`
          state.innerHTML +=opt
          data1.districts.map((data2)=>{
                let opt=`<option>${data2.district_name}</option>`
                district.innerHTML +=opt
        })
    })
})
let p=document.getElementsByTagName("p")
let name=document.getElementById("name")
let door=document.getElementById("door")
let landmark=document.getElementById("landmark")
let street=document.getElementById("street")
let city=document.getElementById("city")
let pincode=document.getElementById("pincode")
/********** name **********************/
name.addEventListener("keyup",()=>{
    let res=/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/
    if(res.test(name.value)){
        p[0].innerText=""
    }
    else{
        p[0].innerText="Invaid name"
    }
})
/************************* door no *******************/
door.addEventListener("keyup",()=>{
    let res=/^[1-9]\d*(?:[ -]?(?:[a-zA-Z]+|[1-9]\d*))?$/
    if(res.test(door.value)){
        p[1].innerText=""
    }
    else{
        p[1].innerText="Invaid House Number"
    }
})
/************************landmark ******************/
landmark.addEventListener("keyup",()=>{
    let res=/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/
    if(res.test(landmark.value)){
        p[2].innerText=""
    }
    else{
        p[2].innerText="Invaid name"
    }
})
/*************************** street *****************/
street.addEventListener("keyup",()=>{
    let res=/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/
    if(res.test(street.value)){
        p[3].innerText=""
    }
    else{
        p[3].innerText="Invaid name"
    }
})
/**************************city ***********************/
city.addEventListener("keyup",()=>{
    let res=/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/
    if(res.test(city.value)){
        p[4].innerText=""
    }
    else{
        p[4].innerText="Invaid name"
    }
})
/****************************pincode ***********************/
pincode.addEventListener("keyup",()=>{
    if(pincode.value<=1000000 & pincode.value>99999){
        p[5].innerText=""
    }
    else{
        p[5].innerText="Invaild pincode"
    }
})
let y=JSON.parse(window.sessionStorage.getItem("admin"))
submit.addEventListener("click",async (e)=>{
    e.preventDefault();
    if(name.value!=""  & door.value!="" & landmark.value!="" & street.value!="" & state.value!="State"  & district.value!="district" & city.value!="" & pincode.value!="" ){
        let building={
        "building_name":name.value,
        "address":{
            "door_No":door.value,
            "landmark":landmark.value,
            "street":street.value,
            "city":city.value,
            "state":state.value,
            "district":district.value,
            "pincode":pincode.value        
        }
        }
        try{
            const response = await fetch(`http://localhost:9090/building?admin_id=${y.id}`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(building),
        });
        if(response.ok){
          const data = await response.json();
          window.alert("Congratulations you have successfully created ");
          
          function save() {
            window.open(URL="http://127.0.0.1:5500/Admin/Html/Admin.html","_self");
          }
      
          save();
        } 
        if (response.status == 404) {
          window.alert("account not found ");
        }
        else{
            alert("building not save")
        } 
    }
    catch(error){
      window.alert("error", error);
    }
}
    else{
        window.alert("plz enter all details")
    }
})