/************     delete  *********/
async function  deleted(id){
// console.log(id);
    try {
        const response=await fetch(`http://localhost:9090/deleteBuilding?id=${id}`,{
        method: "DELETE",
        headers: {
        "Content-Type": "application/json",
      }
    })
    console.log(response.status)
        if(response.status ==302){
            alert("Account delete successfully");
            let y=JSON.parse(window.sessionStorage.getItem("admin"))
            try {
                const response=await fetch(`http://localhost:9090/fetchBuildingByadmin?id=${y.id}`)
                let x=await response.json();        
                window.sessionStorage.setItem("Buliding",JSON.stringify(x.data))
            } catch (error) {
                console.log(error)
            }
        }
        else if(response.ok){
            alert("Sorry  Account not found");
        }
        else{
            alert("Account not delete successfully");
        }
    } catch (error) {
        window.alert(error)
    }
update();
}
/************************update ***********************/
function update(){
    let y=JSON.parse(window.sessionStorage.getItem("Buliding"))
        let tablebody=document.getElementById("tbody");
        let str="";
        y.map((data)=>{ 
            if(data.manager!=null){
                str+=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="Name">${data.building_name}</td>
                <td class="ratings">${data.ratings}</td>
                <td class="manager">${data.manager.name}</td>
                <td class="address">${data.address.door_No},${data.address.street},<br>${data.address.landmark},,<br>${data.address.city},${data.address.district},<br>${data.address.state}.<br>${data.address.pincode}</td>
                <td><button class="button"  onclick="AddFloor(${data.id},${data.admin.id})">AddFloor</button></td>
                <td><button class="button"  onclick="deleted(${data.id})">DeleteBuilding</button></td>
                </tr>` 
            }
            else{
                str+=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="Name">${data.building_name}</td>
                <td class="ratings">${data.ratings}</td>
                <td><button class="button"  onclick="AddManager(${data.id},${data.admin.id})">AddManager</button></td>
                <td class="address">${data.address.door_No},${data.address.street},<br>${data.address.landmark},<br>${data.address.city},${data.address.district},<br>${data.address.state}.<br>${data.address.pincode}</td>
                <td><button class="button"  onclick="AddFloor(${data.id},${data.admin.id})">AddFloor</button></td>
                <td><button class="button"  onclick="deleted(${data.id})">DeleteBuilding</button></td>
                </tr>`
            }
            
        })
        tablebody.innerHTML=str;
}
update();
async function AddManager(b_id,a_id){
  try {
    const responses=await fetch(`http://localhost:9090/fetchManagers`)
    let x=await responses.json();
    console.log(x.data);
    let tablebody=document.getElementById("tbody1");
    let table=document.getElementById("table");
    table.style.display="block"
    let str=""; 
    x.data.map((Data)=>{
        str+=`<tr>
                <th scope="row" class="id">${Data.id}</th>
                <td class="Name">${Data.name}</td>
                <td class="Experiance">${Data.experiance}</td>
                <td><button class="button"  onclick="Manager(${Data.id},${a_id},${b_id})">AddManager</button></td>
                <tr>`
    })
    str+=`<tr>
    <td>
        <button id="Back"  onclick="back()">Back</button>
    </td>
</tr>`
    tablebody.innerHTML=str;
  } catch (error) {
    alert(error)
  }
}
function back(){
    let table=document.getElementById("table");
    table.style.display="none" 
}
async function Manager(id,a_id,b_id){
    try {
        const response=await fetch(`http://localhost:9090/addManager?admin_id=${a_id}&building_id=${b_id}&manager_id=${id}`,{
            method: "PUT",
            headers: {
            "Content-Type": "application/json",
          }
        })
        // console.log(response)
        const responses=await fetch(`http://localhost:9090/fetchBuildingByadmin?id=${a_id}`)
        let x=await responses.json();        
        window.sessionStorage.setItem("Buliding",JSON.stringify(x.data))
        let table=document.getElementById("table");
        table.style.display="none"
      } catch (error) {
        console.log(error)
      }
    update();
}
async function AddFloor(b_id,a_id){
    let floor_number= prompt("Enter Floor Number", );
    if(floor_number!=0 & floor_number!=null){
        try {
          const response=await fetch(`http://localhost:9090/addFloor?building_id=${b_id}`,{
              method: "PUT",
              headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
                "floor_Number":floor_number
            }),
          })
          let z=await response.json();
          console.log(z.data)
          const responses=await fetch(`http://localhost:9090/fetchBuildingByadmin?id=${a_id}`)
                      let x=await responses.json();        
                      window.sessionStorage.setItem("Buliding",JSON.stringify(x.data))
        } catch (error) {
          console.log(error)
        }
    }
  update();
  }
  






