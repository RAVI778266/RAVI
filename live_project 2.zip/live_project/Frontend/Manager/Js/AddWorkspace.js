async function  fun() {
    let str=`<option value="" selected disabled>Select your Availability</option>`
    let b=JSON.parse(window.sessionStorage.getItem("building"))
    b.floors.map((data)=>{
        str+=`<option value="${data.id}">${data.id}</option>`
    })
    floor.innerHTML=str
}
fun()
submit.addEventListener("click",async (e)=>{
    e.preventDefault();
    // let table=document.getElementById("table")
    let y=JSON.parse(window.sessionStorage.getItem("manager"))
    let f_id=floor.value
    console.log(f_id);
    if(Capacity.value!=""&f_id!=0 & Workspace.value!="" & priceperday.value!="" & availability.value!="" & squarefeet.value!="" ){
        // table.style.display="block"
        let workspace={
            "capacity" :  Capacity.value,
            "type" : Workspace.value,
            "pricePerDay":priceperday.value,
            "availability" :availability.value,
            "squarefeet":squarefeet.value
        }
        // console.log(Workspace.value);
        // let f_id=fun()
        // console.log(f_id);
     try{
            const response = await fetch(`http://localhost:9090/addworkspacebyManager?manager_id=${y.id}&floor_id=${f_id}`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(workspace)
        });
        console.log(response)
        if(response.ok){
          const data = await response.json();
          window.alert("Congratulations you have Add workspace");
        //   function save() {
            // table.style.display="none"
            window.open(URL="http://127.0.0.1:5500/Manager/Html/Manager.html","_self");
        //   }
        //   save();
        //   console.log(Workspace.value)
        }
    }
    catch(error){
      window.alert("error", error);
    }
}
    else{
        window.alert("plz enter all details")
    }
})
/*async function fun() {
            let str=""
            let b=JSON.parse(window.sessionStorage.getItem("building"))
            b.floors.map((data)=>{
                str +=`<tr>
                <th scope="row" class="id">${data.id}</th>
                <td class="capacity">${data.floor_Number}</td>
                <td><button class="button"  onclick="addfloor(${data.id})">Add Floor Id</button></td>
                </tr>`
            })
            let tbody=document.getElementById("tbody")
            tbody.innerHTML=str
}
async function addfloor(id) {
    console.log(id);
    table.style.display="none"
}*/