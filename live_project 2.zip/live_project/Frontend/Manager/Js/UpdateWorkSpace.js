let z=JSON.parse(window.sessionStorage.getItem("workspace"))
Capacity.value=z.capacity
Workspace.value=z.type
priceperday.value=z.pricePerDay
availability.value=z.availability
squarefeet.value=z.squarefeet
submit.addEventListener("click",async (e)=>{
    e.preventDefault();
    if(Capacity.value!="" & Workspace.value!="" & priceperday.value!="" & availability.value!="" & squarefeet.value!="" ){
        let workspace={
            "capacity" :  Capacity.value,
            "type" : Workspace.value,
            "pricePerDay":priceperday.value,
            "availability" :availability.value,
            "squarefeet":squarefeet.value
        }
        // console.log(Workspace.value);
        try{
            const response = await fetch(`http://localhost:9090/updateWorkSpace?id=${z.id}`,
        {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(workspace)
        });
        console.log(response)
        if(response.ok){
          window.alert("Congratulations you have update the workspace");
        async  function save() {
            // try {
            //     const response=await fetch(`http://localhost:9090/fetchWorkSpaces`)
            //     let x=await response.json();      
            //     window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
            //     window.open(URL="http://127.0.0.1:5500/Manager/Html/ShowWorkSpace.html","_self");
            // } catch (error) {
            //     alert(error)
            // }
            try {
                let y=JSON.parse(window.sessionStorage.getItem("manager"))
                const response=await fetch(`http://localhost:9090/fetchWorkSpaceByManager?id=${y.id}`)
                // console.log(response);
                let x=await response.json();
                // console.log(x)   
                if(response.status==302){
                    window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
                    window.open(URL="http://127.0.0.1:5500/Manager/Html/ShowWorkSpace.html","_self");
                }
                else{
                    alert(x.data)
                }
            } catch (error) {
                alert(error)
            }
          }
          save();
        //   console.log(Workspace.value)
        }
    }
    catch(error){
      window.alert("error", error);
    }
}
    else{
        window.alert("plz enter all details")
    }
})