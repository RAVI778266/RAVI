/************     delete  *********/
async function  deleted(id){
    // console.log(id);
        try {
            const response=await fetch(`http://localhost:9090/deleteWorkSpace?id=${id}`,{
            method: "DELETE",
            headers: {
            "Content-Type": "application/json",
          }
        })
        // console.log(response.status)
            if(response.status==202){
                alert("Account delete successfully");
                try {
                    const response=await fetch(`http://localhost:9090/fetchWorkSpaces`)
                    // console.log(response);
                    let x=await response.json();
                    // console.log(x)        
                    window.sessionStorage.setItem("workspaces",JSON.stringify(x.data));
                } catch (error) {
                    alert(error)
                }
            }
            else if(response==404){
                alert("Sorry  Account not found");
            }
            else{
                alert("Account not delete successfully");
            }
        } catch (error) {
            window.alert(error)
        }
    update();
    }
    /************************update ***********************/
    function update(){
        let y=JSON.parse(window.sessionStorage.getItem("workspaces"))
            let tablebody=document.getElementById("tbody");
            let str="";
            // console.log(y)
            // if(y=="workSpace not Found"){
                
            // }
            // else{
                y.map((data)=>{ 
                    str+=`<tr>
                    <th scope="row" class="id">${data.id}</th>
                    <td class="capacity">${data.capacity}</td>
                    <td class="type">${data.type}</td>
                    <td class="pricePerDay">${data.pricePerDay}</td>
                    <td class="availability">${data.availability}</td>
                    <td class="squarefeet">${data.squarefeet}</td>
                    <td><button class="button"  onclick="updateWorkspace(${data.id})">updateWorkspace</button></td>
                    <td><button class="button"  onclick="deleted(${data.id})">DeleteWorkspace</button></td>
                    </tr>`                 
                })
                tablebody.innerHTML=str;
            // }
    }
    update();
    async function updateWorkspace(id) {
        try {
            const response=await fetch(`http://localhost:9090/fetchWorkSpaceById?id=${id}`)
            let w=await response.json()
            window.sessionStorage.setItem("workspace",JSON.stringify(w.data));
            // console.log(w.data)
            window.open(URL="http://127.0.0.1:5500/Manager/Html/UpdateWorkSpace.html","_self");
        } catch (error) {
            alert(error)
        }
    }