window.fetch("/Indian_States_and_Districts.Json").then((data)=>data.json())
    .then((res)=>{
        res.map((data1)=> {
          let opt=`<option>${data1.state_name}</option>`
          state.innerHTML +=opt
          data1.districts.map((data2)=>{
                let opt=`<option>${data2.district_name}</option>`
                district.innerHTML +=opt
        })
    })
})

let name=document.getElementById("name")
let email=document.getElementById("email")
let password=document.getElementById("password")
let phone=document.getElementById("phone")
let experiance=document.getElementById("experiance")
let door=document.getElementById("door")
let landmark=document.getElementById("landmark")
let street=document.getElementById("street")
let city=document.getElementById("city")
let pincode=document.getElementById("pincode")
let y=JSON.parse(window.sessionStorage.getItem("manager"))
// let state=document.getElementById("state")
// let district=document.getElementById("district")
name.value=y.name
email.value=y.email
password.value=y.pwd
phone.value=y.phone
experiance.value=y.experiance
door.value=y.address.door_No
landmark.value=y.address.landmark
street.value=y.address.street
city.value=y.address.city
pincode.value=y.address.pincode
// state.value=y.address.state
// district.value=y.address.district
s.innerText=y.address.state
d.innerText=y.address.district
console.log(y.pwd)
submit.addEventListener("click",async (e)=>{
    e.preventDefault();
    let check_gender=document.getElementsByName("gender")
    let gender=y.gender
    for(let i=0;i<check_gender.length;i++){
        if(check_gender[i].checked){   
            gender=check_gender[i].value
        }
    }
    if(name.value!="" & email.value!="" & password.value!="" & phone.value!="" & experiance.value!="" & door.value!="" & landmark.value!="" & street.value!="" & state.value!="State"  & district.value!="district" & city.value!="" & pincode.value!="" ){
        let manager={
        "name":name.value,
        "email":email.value,
        "phone":phone.value,
        "pwd":password.value,
        "gender":gender,
        "experiance":experiance.value,
        "address":{
            "door_No":door.value,
            "landmark":landmark.value,
            "street":street.value,
            "city":city.value,
            "state":state.value,
            "district":district.value,
            "pincode":pincode.value        
        }
        }
        console.log(manager)
        try{
            const response = await fetch(`http://localhost:9090/updateManager?id=${y.id}`,
        {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(manager),
        });
        if(response.ok){
          const x = await response.json();
          window.sessionStorage.setItem("manager",JSON.stringify(x.data))
          window.alert("Congratulations you have successfully update ");
          function save() {
            window.open(URL="http://127.0.0.1:5500/Manager/Html/Manager.html","_self");
          }
          save();
        }
        if (response.status >= 400) {
          window.alert("Youre Already Registered");
        }
    }
    catch(error){
      window.alert("error", error);
    }
}
    else{
        window.alert("plz enter all details")
    }
})
