async function fun(){
    try {
        let y=JSON.parse(window.sessionStorage.getItem("manager"))
        const response=await fetch(`http://localhost:9090/fetchBulidingByManagger?manager_id=${y.id}`)
        let x=await response.json();  
        if(response.status==302){
            window.sessionStorage.setItem("building",JSON.stringify(x.data))
            cointaner.style.display="flex"
            image.style.display="none"
        }
        else if(response.status==404){
            cointaner.style.display="none" 
            image.style.display="block"
        }
        else{
            cointaner.style.display="none" 
            alert(x.data)
        }
    } catch (error) {
        alert(error)
    } 
}
fun()
async function o(){
    console.log("click");
    try {
        let y=JSON.parse(window.sessionStorage.getItem("manager"))
        const response=await fetch(`http://localhost:9090/fetchAceptManager?id=${y.id}`,{
            method: "GET",
            headers: {
            "Content-Type": "application/json",
          }
        })
        let table=document.getElementById("pop_up");
        if(response.status==302){
            let responses=await response.json()
            let w=responses.data
            let pre=""
            w.map(async(data)=>{
                if(data.status==null){
                    table.style.display="block"
                    console.log(data)
                    pre+=`<pre>
                    You have get a booking  from <span>${data.client_id}</span>
                    workspace <span>${data.workSpace.type}</span>
                    from <span>${new Date(data.entryDate)}</span> to <span>${data.exitDate}</span>
                    the payment cost is <span>${data.payment}</span> <br>
                    <button onclick="accepted(${data.booking_id})">accepted</button>  <button onclick="reject(${data.booking_id})">reject</button></pre><br>`
            }
        })
        pre+=`<br><button id="Back"  onclick="back()">Back</button>`
        table.innerHTML=pre
    }
    else if (response.status==404){
        alert("no bookings")
    }
    else{
        table.style.display="none"
    }
    } catch (error) {
        alert(error)
    }
}
async function accepted(id){   
    let text="ok"
    const x=await fetch(`http://localhost:9090/addStatus?status=${text}&id=${id}`,{
method: "PUT",
headers: {
    "Content-Type": "application/json",
},
})
o();
}
async function reject(id){
    let text="canceled"
    const x=await fetch(`http://localhost:9090/addStatus?status=${text}&id=${id}`,{
method: "PUT",
headers: {
    "Content-Type": "application/json",
},
})
o();
}
function back(){
    let table=document.getElementById("pop_up");
    table.style.display="none" 
}
update.addEventListener("click",(e)=>{
    e.preventDefault()    
    window.open(URL="http://127.0.0.1:5500/Manager/Html/Update.html","_self")
})

Delete.addEventListener("click",async (e)=>{
    let y=JSON.parse(window.sessionStorage.getItem("manager"))
    e.preventDefault()    
    try {
        const response=await fetch(`http://localhost:9090/deleteManager?id=${y.id}`,{
        method: "DELETE",
        headers: {
        "Content-Type": "application/json",
      }
    })
        if(response.status ==201){
            alert("Account delete successfully");
            window.open(URL="http://127.0.0.1:5500/Manager/Html/Login.html","_self");
            window.sessionStorage.removeItem("manager")
        }
        else if(response.status==200){
            alert("Sorry  Account not found");
        }
        else{
            alert("Account not delete successfully");
        }
    } catch (error) {
        window.alert(error)
    }
},false)

Fetch.addEventListener("click",async (e)=>{
    window.open(URL="http://127.0.0.1:5500/Manager/Html/Profile.html","_self");
},false)

addWorkSpace.addEventListener("click",()=>{
    let y=JSON.parse(window.sessionStorage.getItem("building"))
    if(y.floors.length!=0){
        window.open(URL="http://127.0.0.1:5500/Manager/Html/AddWorkSpace.html","_self");
    }
})
logout.addEventListener("click",async()=>{
    window.sessionStorage.clear()
    window.open(URL="http://127.0.0.1:5500/index.html","_self");
})

showWorkspace.addEventListener("click",async()=>{
    try {
        let y=JSON.parse(window.sessionStorage.getItem("manager"))
        const response=await fetch(`http://localhost:9090/fetchWorkSpaceByManager?id=${y.id}`)
        // console.log(response);
        let x=await response.json();
        // console.log(x)   
        if(response.status==302){
            window.sessionStorage.setItem("workspaces",JSON.stringify(x.data))
            window.open(URL="http://127.0.0.1:5500/Manager/Html/ShowWorkSpace.html","_self");
        }
        else{
            alert(x.data)
        }
    } catch (error) {
        alert(error)
    }
    // let y=JSON.parse(window.sessionStorage.getItem("workspaces"))
    // console.log(y);
},false)




