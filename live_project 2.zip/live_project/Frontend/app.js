// let from =document.getElementById("form");
// from.addEventListener("submit",(e)=>{
//     e.preventDefault();
//     let name=document.getElementById("name").value
//     let password=document.getElementById("password").value
//     window.localStorage.setItem("name",name)
//     window.localStorage.setItem("password",password)
//     console.log(window.localStorage.getItem("name"))
//     console.log(window.localStorage.getItem("password"))
// })
let loc=document.getElementById("loc")
loc.addEventListener("mousemove",()=>{
    window.fetch("state.json")
    .then((data)=>data.json())
    .then((res)=>{
    res.map((data1)=> {
     let ol=document.getElementById("ol")     
     let li=`<li>${data1.name.default}</li>`
     ol.innerHTML +=li
     ol.style.display="block"
     ol.style.border="2px solid"
    }) 
    })
})

let ol=document.getElementById("ol") 
ol.addEventListener("mouseleave",()=>{
    ol.style.display="none"
})
loc.addEventListener("mouseleave",()=>{
    ol.style.display="none"
})
let admin=document.getElementById("admin")
/*admin.addEventListener("mouseenter",()=>{
    let div=document.getElementById("admindiv")
    div.innerHTML=`<button>Login</button><button>Sigup</button>`
    div.style.display="block"
    
})
let div=document.getElementById("admindiv")
div.addEventListener("mouseout",()=>{
    div.innerHTML=`<button>Login</button><button>Sigup</button>`
    div.style.display="none"
    
})
// admin.addEventListener("mouseout",()=>{
//     div.innerHTML=`<button>Login</button><button>Sigup</button>`
//     div.style.display="none"
// })*/
admin.addEventListener("click",()=>{
    window.open("http://127.0.0.1:5500/Admin/Html/Login.html")
})
let client=document.getElementById("client")
client.addEventListener("click",()=>{
    window.open("http://127.0.0.1:5500/Client/Html/Login.html")
})
let manager=document.getElementById("manager")
manager.addEventListener("click",()=>{
    window.open("http://127.0.0.1:5500/Manager/Html/Login.html")
})








