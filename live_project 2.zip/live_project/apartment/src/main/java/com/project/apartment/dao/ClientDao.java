package com.project.apartment.dao;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Client;
import com.project.apartment.repo.ClientRepo;


@Repository
public class ClientDao {

	@Autowired
	private ClientRepo clientRepo;
	
	public Client saveClient(Client client) {
		return clientRepo.save(client);
	}

	public Client fetchById(int client_id) {
		Optional<Client> db=clientRepo.findById(client_id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}

	public void deleteClient(Client db) {
		clientRepo.delete(db);		
	}

	public Client fetchEmail(String email) {
		return clientRepo.fetchEmail(email);
	}

	public Client clientLogin(String email, String password) {
		return clientRepo.clientLogin(email, password);
	}
}