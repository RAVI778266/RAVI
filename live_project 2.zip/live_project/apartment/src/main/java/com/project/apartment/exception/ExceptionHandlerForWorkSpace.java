package com.project.apartment.exception;

import java.sql.SQLIntegrityConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.project.apartment.util.ResponseStructure;

@RestControllerAdvice
public class ExceptionHandlerForWorkSpace {

	@ExceptionHandler(SQLIntegrityConstraintViolationException.class)
	public ResponseEntity<ResponseStructure<String>>sqlExceptionHandler(SQLIntegrityConstraintViolationException e){
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setData(e.getMessage());
		structure.setMessage("you can't perform this operation");
		structure.setStatus(HttpStatus.BAD_REQUEST.value());
		return new ResponseEntity<ResponseStructure<String>>(structure, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AdminIdNotFound.class)
	public ResponseEntity<ResponseStructure<String>> adminIdNotFound(AdminIdNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setData(e.getMessage());
		structure.setMessage("admin_id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(CardNotFound.class)
	public ResponseEntity<ResponseStructure<String>> CardNotFound(CardNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setData(e.getMessage());
		structure.setMessage("");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(BuildingNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> buildingNotFoundException(BuildingNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Buildings not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(AdminEmailNotFound.class)
	public ResponseEntity<ResponseStructure<String>> adminEmailNotFound(AdminEmailNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Admin with the email not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(AdminDoorNoNotFound.class)
	public ResponseEntity<ResponseStructure<String>> adminDoorNoNotFound(AdminDoorNoNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Admin with the Door No not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(AdminPasswordNotFound.class)
	public ResponseEntity<ResponseStructure<String>> adminPasswordNotFound(AdminPasswordNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Admin with the password not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ManagerIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> managerIdNotFoundException(ManagerIdNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Manager with the Id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ClientIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> clientIdNotFoundException(ClientIdNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Client with the id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ClientBookingIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> clientBookingIdNotFoundException(ClientBookingIdNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("ClientBooking with the Id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(FloorIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> FloorIdNotFoundException(AdminDoorNoNotFound e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Floor with the Id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ManagerPasswordNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> managerPasswordNotFoundException(ManagerPasswordNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Manager with Password not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ManagerEmailNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> managerEmailNotFoundException(ManagerEmailNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Manager with Email not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(WorkSpaceIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> workSpaceIdNotFoundException(WorkSpaceIdNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("WorkSpace with Id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(WorkSpaceNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> workSpaceNotFoundException(WorkSpaceNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("WorkSpace is empty");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ClientPasswordNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> clientPasswordNotFoundException(ClientPasswordNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Client with Password not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ClientEmailNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> clientEmailNotFoundException(ClientEmailNotFoundException e){
		ResponseStructure<String> structure=new ResponseStructure<>();
		structure.setData(e.getMessage());
		structure.setMessage("Client with Email not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
}
