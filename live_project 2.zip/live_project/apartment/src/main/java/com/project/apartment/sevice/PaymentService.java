package com.project.apartment.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.PaymentDao;
import com.project.apartment.dto.Payment;
import com.project.apartment.exception.CardNotFound;
import com.project.apartment.util.ResponseStructure;

@Service
public class PaymentService {

	@Autowired
	private PaymentDao paymentDao;

	public ResponseEntity<ResponseStructure<Payment>> fetchCard(long card, int cvv) {
		Payment db=paymentDao.fetchCard(card,cvv);
		if(db!=null){
			ResponseStructure<Payment> st=new ResponseStructure<Payment>();
			st.setData(db);
			st.setStatus(HttpStatus.FOUND.value());
			st.setMessage("fetch successfully");
			return new ResponseEntity<ResponseStructure<Payment>>(st, HttpStatus.FOUND); 
		}
		else
			throw new CardNotFound("");
	}
}
