package com.project.apartment.exception;

public class ManagerEmailNotFoundException extends RuntimeException {

	public ManagerEmailNotFoundException(String message) {
		super(message);
	}

}
