package com.project.apartment.enums;

public enum WorkSpaceEnum {
	caftera,
	bedroom,
	breakoutSpaces,
	assignedWorkspace,
	coworkingspace,
	coffice,
	ConferenceRoom,
	connectedOffices,
	creativeSpaces,
	cubicleFarm,
	hotdesks,
	focusRoom,
	funZones,
	meetingSpaces,
	

}
