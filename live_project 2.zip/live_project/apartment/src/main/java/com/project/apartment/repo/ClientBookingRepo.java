package com.project.apartment.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.apartment.dto.ClientBooking;

public interface ClientBookingRepo extends JpaRepository<ClientBooking, Integer> {

}
