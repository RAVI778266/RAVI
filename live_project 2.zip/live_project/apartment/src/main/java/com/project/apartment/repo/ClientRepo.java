package com.project.apartment.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Client;


public interface ClientRepo extends  JpaRepository<Client,Integer> {
	@Query("select a from Client a where a.email=?1")
	Client fetchEmail(String email);
	@Query("select a from Client a where a.email=?1 and a.pwd=?2") 
	Client clientLogin(String email, String password);


}
