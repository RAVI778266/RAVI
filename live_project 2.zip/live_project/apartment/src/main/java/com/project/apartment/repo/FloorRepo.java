package com.project.apartment.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Floor;

public interface FloorRepo  extends  JpaRepository<Floor, Integer>{
//	@Query("DELETE FROM Floor a WHERE a.workspaces_id=?1 ")
//	void removeWorkspace(int id);

}
