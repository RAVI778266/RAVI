package com.project.apartment.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Admin;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Floor;
import com.project.apartment.dto.Manager;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.repo.BuildingRepo;

@Repository
public class BuildingDao {
	
	@Autowired
	private BuildingRepo buildingRepo;
	
	public Building saveBuilding(Building building) {
		return buildingRepo.save(building);
	}
	
	public List<Building> fetchBasedOnNames(String name){
		return buildingRepo.fetchByBuildingName(name);
	}

	public Building fetchBuilding(int building_id) {
		Optional<Building> db=buildingRepo.findById(building_id);
		if(db!=null) {
			return db.get();
		}
		return null;
	}

	public List<Building> adminAsNull(Admin admin) {
		List<Building> b=buildingRepo.findAll();
		for(Building i:b) {
			if(i.getAdmin().equals(admin)) {
//				i.setAdmin(null);
				buildingRepo.delete(i);
			}		
		}
		return b;
	}

	public List<Building> fetchAll() {
		List<Building> b=buildingRepo.findAll();
		return b;
	}
	
	public List<Building> fetchBylocation(String location) {
		return buildingRepo.fetchByLocation(location);
	}

	public Building deleteBuilding(Building building) {
		buildingRepo.delete(building);
		return building;
	}

	public void dispatchManager(Manager dbmanager) {
		List<Building> b=buildingRepo.findAll();
		for(Building i:b) {
			if(i.getManager().equals(dbmanager)) {
				i.setManager(null);
				buildingRepo.save(i);
			}		
		}
	}
	public Building searchManager(Manager dbmanager) {
//		List<Building> b=buildingRepo.findAll();
//		for(Building i:b) {
//			if(i.getManager().equals(dbmanager)) {
//				return i;
//			}		
//		}
		return buildingRepo.searchManager(dbmanager);
	}

	public Floor searchFloor(Building building, int floor_id) {
		List<Floor>f=building.getFloors();
		for(Floor i:f) {
			if(i.getId()==floor_id) {
				return i;
			}
		}
		return null;
	}

	public List<Building> fetchBuildingByadmin(Admin admin) {
		return buildingRepo.fetchByAdmin(admin);
	}

	public List<WorkSpace> fetchWorkSpaceByBuilding(Building db) {
		List<WorkSpace> w=new ArrayList<WorkSpace>();
		for(Floor i:db.getFloors()) {
			w.addAll(i.getWorkspaces());
		}
		return w;
	}

	public List<Building> findCitys(String city) {
		List<Building> b=buildingRepo.findCitys(city);
		return b;
	}
	public List<String> findCity() {
		List<String> b=buildingRepo.findCity();
		return b;
	}

	public List<Floor> findListFloors(Building dbbuilding) {
		List<Floor> f=dbbuilding.getFloors();
		return f;
	}

	public Floor addfloor(List<Floor> f, Floor floor) {
		for(Floor i:f) {
			if(i.getFloor_Number()==floor.getFloor_Number()) {
				return null;
			}
		}
		return floor;
	}
}