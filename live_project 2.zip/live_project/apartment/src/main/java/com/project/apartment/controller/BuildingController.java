package com.project.apartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Building;
import com.project.apartment.dto.Floor;
import com.project.apartment.sevice.BuildingService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class BuildingController {

	@Autowired
	private BuildingService buildingService;
	
	@PostMapping("/building")
	public ResponseEntity<ResponseStructure<Building>> saveBuilding(@RequestBody Building building,@RequestParam int admin_id){
		return buildingService.saveBuilding(building, admin_id);
	}
	@GetMapping("/fetch")
	public ResponseEntity<ResponseStructure<List<Building>>> fetchBuilding(@RequestParam String build_name){
		return buildingService.FetchBuildingbyBuildingname(build_name);
		
	}
	@PutMapping("/addManager")
	public ResponseEntity<ResponseStructure<Building>> addManager(@RequestParam int building_id,@RequestParam int admin_id,@RequestParam int manager_id){
		return buildingService.addManager(building_id,admin_id,manager_id);                     
	}
	@GetMapping("/fetchAll")
	public ResponseEntity<ResponseStructure<List<Building>>> fetchAll(){
		return buildingService.fetchAll();
	}
	@GetMapping("/fetchBylocation")
	public ResponseEntity<ResponseStructure<List<Building>>> fetchBuildingBylocation(@RequestParam String location){
		return buildingService.FetchBuildingbylocation(location);
	}
	@GetMapping("/fetchById")
	public ResponseEntity<ResponseStructure<Building>> fetchBuildingById(@RequestParam int id){
		return buildingService.FetchBuildingbyId(id);
	}
	@PutMapping("/updateBuilding")
	public ResponseEntity<ResponseStructure<Building>> updateBuilding(@RequestParam int id,@RequestBody Building building){
		return buildingService.updateBuilding(id,building);
	}
	@DeleteMapping("/deleteBuilding")
	public ResponseEntity<ResponseStructure<Building>> deleteBuilding(@RequestParam int id){
		return buildingService.deleteBuilding(id);
	}
	@GetMapping("/fetchBuildingByadmin")
	public ResponseEntity<ResponseStructure<List<Building>>> fetchBuildingByadmin(@RequestParam int id){
		return buildingService.fetchBuildingByadmin(id);
	}
	@PutMapping("/addFloor")
	public ResponseEntity<ResponseStructure<Building>> addFloor(@RequestParam int building_id,@RequestBody Floor floor){
		return buildingService.addFloor(building_id,floor);                     
	}
	@GetMapping("/findCitys")
	public ResponseEntity<ResponseStructure<List<Building>>> findCitys(@RequestParam String city){
		return buildingService.findCitys(city);
	}
	@GetMapping("/findCity")
	public ResponseEntity<ResponseStructure<List<String>>> findCity(){
		return buildingService.findCity();
	}
}
