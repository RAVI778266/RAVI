package com.project.apartment.exception;

public class FloorIdNotFoundException extends RuntimeException{

	public FloorIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
