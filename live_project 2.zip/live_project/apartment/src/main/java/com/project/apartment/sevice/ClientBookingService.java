package com.project.apartment.sevice;

import org.springframework.stereotype.Service;

@Service
public class ClientBookingService {

}
