package com.project.apartment.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.ClientAcept;

public interface ClientAceptRepo extends JpaRepository<ClientAcept,Integer> {
	@Query("select a from ClientAcept a where a.admin_id=?1")
	List<ClientAcept> fetchA(int id);
	@Query("select a from ClientAcept a where a.client_id=?1")
	List<ClientAcept> fetchC(int id);
	@Query("select a from ClientAcept a where a.manager_id=?1")
	List<ClientAcept> fetchM(int id);
}
