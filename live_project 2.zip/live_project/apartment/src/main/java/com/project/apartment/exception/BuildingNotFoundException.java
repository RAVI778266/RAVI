package com.project.apartment.exception;


public class BuildingNotFoundException extends RuntimeException {
	
	public BuildingNotFoundException(String message) {
		super(message);
	}
}