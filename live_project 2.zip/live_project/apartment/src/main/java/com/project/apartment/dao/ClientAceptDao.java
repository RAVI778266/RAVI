package com.project.apartment.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.ClientAcept;
import com.project.apartment.repo.ClientAceptRepo;

@Repository
public class ClientAceptDao {

	@Autowired
	private ClientAceptRepo clientAceptRepo;
	
	public ClientAcept save(ClientAcept clientAcept) {
		return  clientAceptRepo.save(clientAcept);
	}

	public List<ClientAcept> fetchM(int id) {
		/*List<ClientAcept>  db=clientAceptRepo.findAll();
		List<ClientAcept>  dbs=new ArrayList<ClientAcept>();
		for(ClientAcept i:db) {
			if(i.getManager_id()==id) {
				dbs.add(i);
			}
		}
		return dbs;*/
		return clientAceptRepo.fetchM(id);
	}
	public List<ClientAcept> fetchA(int id) {
		/*List<ClientAcept>  db=clientAceptRepo.findAll();
		if(!db.isEmpty()) {
			List<ClientAcept>  dbs=new ArrayList<ClientAcept>();
			for(ClientAcept i:db) {
				if(i.getAdmin_id()==id) {
					dbs.add(i);
				}
				return dbs;
			}	
		}
		return null;*/
		return clientAceptRepo.fetchA(id);
	}
	public List<ClientAcept> fetchC(int id) {
		/*List<ClientAcept>  db=clientAceptRepo.findAll();
		List<ClientAcept>  dbs=new ArrayList<ClientAcept>();
		for(ClientAcept i:db) {
			if(i.getClient_id()==id) {
				dbs.add(i);
			}
		}
		return dbs;*/
		return clientAceptRepo.fetchC(id);
	}

	public ClientAcept deleteAcept(ClientAcept clientAcept) {
		clientAceptRepo.delete(clientAcept);
		return clientAcept;
	}

	public ClientAcept fetch(int id) {
		return clientAceptRepo.findById(id).get();
	}

	public ClientAcept fetchAceptById(int id) {
		Optional<ClientAcept> db=clientAceptRepo.findById(id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}
}
