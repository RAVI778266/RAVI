package com.project.apartment.exception;

public class AdminIdNotFound extends RuntimeException {

//	private String message="Id is not found";

	public AdminIdNotFound(String message) {
		super(message);
	}
	
}