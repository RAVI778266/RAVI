package com.project.apartment.exception;

public class ClientPasswordNotFoundException extends RuntimeException {

	public ClientPasswordNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
