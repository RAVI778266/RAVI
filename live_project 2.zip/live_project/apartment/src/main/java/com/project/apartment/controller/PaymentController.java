package com.project.apartment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Payment;
import com.project.apartment.sevice.PaymentService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class PaymentController {

	@Autowired
	private PaymentService paymentService;
	
	@GetMapping("/fetchCard")
	public ResponseEntity<ResponseStructure<Payment>> fetchCard(@RequestParam long card,@RequestParam int cvv){
		return paymentService.fetchCard(card,cvv);
	}
}
