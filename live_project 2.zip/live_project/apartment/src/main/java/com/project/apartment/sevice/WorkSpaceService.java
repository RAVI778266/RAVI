package com.project.apartment.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.BuildingDao;
import com.project.apartment.dao.FloorDao;
import com.project.apartment.dao.ManagerDao;
import com.project.apartment.dao.WorkSpaceDao;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Floor;
import com.project.apartment.dto.Manager;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;
import com.project.apartment.exception.BuildingNotFoundException;
import com.project.apartment.exception.FloorIdNotFoundException;
import com.project.apartment.exception.ManagerIdNotFoundException;
import com.project.apartment.exception.WorkSpaceIdNotFoundException;
import com.project.apartment.exception.WorkSpaceNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class WorkSpaceService {
	@Autowired
	private WorkSpaceDao workSpaceDao;
	@Autowired
	private FloorDao floorDao;
	@Autowired
	private ManagerDao managerDao;
	@Autowired 
	private BuildingDao buildingDao;
	
	public ResponseEntity<ResponseStructure<WorkSpace>> saveWorkSpace(WorkSpace workSpace, int floor_id) {
		Floor f=floorDao.fetchFloor(floor_id);
		if(f!=null) {
			List<WorkSpace> fw = f.getWorkspaces();
			fw.add(workSpace);
			f.setWorkspaces(fw);
			floorDao.saveFloor(f);
			ResponseStructure<WorkSpace> structure =new ResponseStructure<WorkSpace>();
			structure.setData(workSpaceDao.saveWorkSpace(workSpace));
			structure.setMessage("workSpace save");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<WorkSpace>>(structure,HttpStatus.CREATED);
		}
		else {
			throw new FloorIdNotFoundException(floor_id+" Floor_id not Found");
		}
	}

	public ResponseEntity<ResponseStructure<WorkSpace>> updateWorkSpace(int id, WorkSpace workSpace) {
		WorkSpace dbwork=workSpaceDao.FetchWorkSpaceById(id);
		if(dbwork!=null) {
			if(workSpace.getAvailability()!=null) {
				dbwork.setAvailability(workSpace.getAvailability());
			}
			if(workSpace.getType()!=null) {
				dbwork.setType(workSpace.getType());
			}
			if(workSpace.getCapacity()!=0) {
				dbwork.setCapacity(workSpace.getCapacity());
			}
			if(workSpace.getPricePerDay()!=0) {
				dbwork.setPricePerDay(workSpace.getPricePerDay());
			}
			if(workSpace.getSquarefeet()!=null) {
				dbwork.setSquarefeet(workSpace.getSquarefeet());
			}
			ResponseStructure<WorkSpace> structure =new ResponseStructure<WorkSpace>();
			structure.setData(workSpaceDao.saveWorkSpace(dbwork));
			structure.setMessage("workSpace save");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<WorkSpace>>(structure,HttpStatus.CREATED);
		}
		else {
			throw new WorkSpaceIdNotFoundException(id+" Floor_id not Found");
		}
	}

	public ResponseEntity<ResponseStructure<WorkSpace>> deleteWorkSpace(int id) {
		WorkSpace dbwork=workSpaceDao.FetchWorkSpaceById(id);
		if(dbwork!=null) {
			floorDao.removeWorkspace(dbwork);
			workSpaceDao.deleteWorkSpace(dbwork);
			ResponseStructure<WorkSpace> structure =new ResponseStructure<WorkSpace>();
			structure.setData(null);
			structure.setMessage("workSpace save");
			structure.setStatus(HttpStatus.ACCEPTED.value());
			return new ResponseEntity<ResponseStructure<WorkSpace>>(structure,HttpStatus.ACCEPTED);
		}
		else {
			throw new WorkSpaceIdNotFoundException(id+" WorkSpace_id not Found");
		}
	}

	public ResponseEntity<ResponseStructure<WorkSpace>> fetchWorkSpaceById(int id) {
		WorkSpace dbwork=workSpaceDao.FetchWorkSpaceById(id);
		if(dbwork!=null) {
			ResponseStructure<WorkSpace> structure =new ResponseStructure<WorkSpace>();
			structure.setData(dbwork);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<WorkSpace>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceIdNotFoundException(id+" WorkSpace_id not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaces() {
		List<WorkSpace> db=workSpaceDao.fetchWorkSpaces();
//		if(!db.isEmpty()) {
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
//		}
//		else {
//			throw new WorkSpaceNotFoundException(" workSpace not Found");
//		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByType(WorkSpaceEnum type) {
		List<WorkSpace> db=workSpaceDao.fetchWorkSpaceByType(type);
		if(!db.isEmpty()) {
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByLocation(String location) {
		List<WorkSpace> db=workSpaceDao.fetchWorkSpaceByLocation(location);
		if(!db.isEmpty()) {
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByCost(double cost) {
		List<WorkSpace> db=workSpaceDao.fetchWorkSpaceByCost(cost);
		if(!db.isEmpty()) {
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByCapacity(String capacity) {
		List<WorkSpace> db=workSpaceDao.fetchWorkSpaceByCapacity(capacity);
		if(!db.isEmpty()) {
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<WorkSpace>> saveWorkSpaceByManager(WorkSpace workSpace, int manager_id) {
		Manager  m=managerDao.fetchManger(manager_id);
		if(m!=null) {
			
//			List<WorkSpace> fw = f.getWorkspaces();
//			fw.add(workSpace);
//			f.setWorkspaces(fw);
//			floorDao.saveFloor(f);
			ResponseStructure<WorkSpace> structure =new ResponseStructure<WorkSpace>();
			structure.setData(workSpaceDao.saveWorkSpace(workSpace));
			structure.setMessage("workSpace save");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<WorkSpace>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByBuilding(int id) {
		Building db=buildingDao.fetchBuilding(id);
		if(db!=null) {
			List<WorkSpace> w=buildingDao.fetchWorkSpaceByBuilding(db);
			ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
			structure.setData(w);
			structure.setMessage("workSpace fetch");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new WorkSpaceNotFoundException(" workSpace not Found");
		}
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> filterWorkSpace(Double price, Double price1,
			WorkSpaceEnum type, int capacity, int capacity1) {
		List<WorkSpace> db=workSpaceDao.filterWorkSpace(price,price1,type,capacity,capacity1);
		ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
		structure.setData(db);
		structure.setMessage("workSpace fetch");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> filterWorkSpace(Double price, Double price1, int capacity,
			int capacity1) {
		List<WorkSpace> db=workSpaceDao.filterWorkSpace(price,price1,capacity,capacity1);
		ResponseStructure<List<WorkSpace>> structure =new ResponseStructure<>();
		structure.setData(db);
		structure.setMessage("workSpace fetch");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure,HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByManager(int id) {
		Manager dbmanager=managerDao.fetchManger(id);
		if(dbmanager != null) {
		Building dbbuilding= buildingDao.searchManager(dbmanager);
		if(dbbuilding!=null) {
			List<Floor> f=buildingDao.findListFloors(dbbuilding);
			if(f!=null) {
				ResponseStructure<List<WorkSpace>> structure=new ResponseStructure<>();
				structure.setData(workSpaceDao.fetchWorkSpaceByManager(f));
				structure.setMessage("add successfully");
				structure.setStatus(HttpStatus.FOUND.value());
				return new ResponseEntity<ResponseStructure<List<WorkSpace>>>(structure, HttpStatus.FOUND);
			}
			else 
				throw new FloorIdNotFoundException(id+" floor_id not Found");
		}
		else 
			throw new BuildingNotFoundException(" Building not Found");
		}
		else 
			throw new ManagerIdNotFoundException( id+" Manager_id not Found");
	}	
}
