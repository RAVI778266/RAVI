package com.project.apartment.exception;

public class AdminEmailNotFound extends RuntimeException{

	public AdminEmailNotFound(String message) {
		super(message);
	}
	
}
