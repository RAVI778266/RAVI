package com.project.apartment.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Manager;

public interface ManagerRepo extends JpaRepository<Manager, Integer> {
	@Query("select a from Manager a where a.experiance=?1")
	List<Manager> fetchManagersByExperiance(int experiance);
	@Query("select a from Manager a where a.email=?1")
	Manager fetchEmail(String email);
	@Query("select a from Manager a where a.email=?1 and a.pwd=?2")
	Manager managerLogin(String email,String password);
}
