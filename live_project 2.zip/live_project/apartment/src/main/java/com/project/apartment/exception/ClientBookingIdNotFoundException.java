package com.project.apartment.exception;

public class ClientBookingIdNotFoundException extends RuntimeException{

	public ClientBookingIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
