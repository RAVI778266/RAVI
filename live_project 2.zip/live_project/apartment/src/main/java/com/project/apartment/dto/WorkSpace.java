package com.project.apartment.dto;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.project.apartment.enums.WorkSpaceEnum;

import lombok.Data;
@Data
@Entity
public class WorkSpace {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private int capacity;
	private WorkSpaceEnum type;
	private double pricePerDay;
	private String availability;
	private String squarefeet;
	
	@ManyToMany
	private List<Client>clients;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public WorkSpaceEnum getType() {
		return type;
	}

	public void setType(WorkSpaceEnum type) {
		this.type = type;
	}

	public double getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getSquarefeet() {
		return squarefeet;
	}

	public void setSquarefeet(String squarefeet) {
		this.squarefeet = squarefeet;
	}

	public List<Client> getClients() {
		return clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}
	

}
