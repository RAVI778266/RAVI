package com.project.apartment.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Address;
import com.project.apartment.dto.Admin;
import com.project.apartment.repo.AddressRepo;

@Repository
public class AddressDao {
	 
	@Autowired
	private AddressRepo addressRepo;

	public Address saveAddress(Address address, int id) {
		Address db= addressRepo.findById(id).get();
		if(db!=null) {
			db.setDoor_No(address.getDoor_No());
			db.setLandmark(address.getLandmark());
			db.setStreet(address.getStreet());
			db.setCity(address.getCity());
			db.setDistrict(address.getDistrict());
			db.setState(address.getState());
			db.setPincode(address.getPincode());
		}
		return addressRepo.save(db);
	}
}
