package com.project.apartment.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.project.apartment.dao.ClientAceptDao;
import com.project.apartment.dto.ClientAcept;
import com.project.apartment.exception.AdminIdNotFound;
import com.project.apartment.exception.ClientIdNotFoundException;
import com.project.apartment.exception.ManagerIdNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class ClientAceptService {
	
	@Autowired
	private ClientAceptDao  clientAceptDao;

	public ResponseEntity<ResponseStructure<ClientAcept>> save(ClientAcept clientAcept) {
		ResponseStructure<ClientAcept> structure=new ResponseStructure<ClientAcept>();
		structure.setData(clientAceptDao.save(clientAcept));
		structure.setMessage("Admin saved successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<ClientAcept>>(structure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<ClientAcept>> addStatus(String s, int id) {
		ClientAcept db = clientAceptDao.fetchAceptById(id);
		if(db!=null) {
		db.setStatus(s);
		ResponseStructure<ClientAcept> structure=new ResponseStructure<ClientAcept>();
		structure.setData(clientAceptDao.save(db));
		structure.setMessage("Admin saved successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<ClientAcept>>(structure, HttpStatus.CREATED);
	}
	else 
		throw new ClientIdNotFoundException(id+"id is not present");
	}

	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptManager(int id) {
		List<ClientAcept> db=clientAceptDao.fetchM(id);
		if(db!=null) {
			ResponseStructure<List<ClientAcept>> structure=new ResponseStructure<List<ClientAcept>>();
			structure.setData(db);
			structure.setMessage("fetch successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<ClientAcept>>>(structure, HttpStatus.FOUND);
		}
		else
			throw new ManagerIdNotFoundException(id+" Manager_id is not present");
	}
	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptAdmin(int id) {
		List<ClientAcept> db=clientAceptDao.fetchA(id);
		if(db!=null) {
			ResponseStructure<List<ClientAcept>> structure=new ResponseStructure<List<ClientAcept>>();
			structure.setData(db);
			structure.setMessage("fetch successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<ClientAcept>>>(structure, HttpStatus.FOUND);
		}
		else
			throw new AdminIdNotFound(id+" Admin_id is not present");
	}
	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptClient(int id) {
		List<ClientAcept> db=clientAceptDao.fetchC(id);
		if(db!=null) {
			ResponseStructure<List<ClientAcept>> structure=new ResponseStructure<List<ClientAcept>>();
			structure.setData(db);
			structure.setMessage("fetch successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<ClientAcept>>>(structure, HttpStatus.FOUND);
		}
		else
			throw new ClientIdNotFoundException(id+" Client_id is not present");
	}

	public ResponseEntity<ResponseStructure<ClientAcept>> deleteAcept(int id) {
		ClientAcept db = clientAceptDao.fetch(id);
		ResponseStructure<ClientAcept> structure=new ResponseStructure<ClientAcept>();
		structure.setData(clientAceptDao.deleteAcept(db));
		structure.setMessage("Admin saved successfully");
		structure.setStatus(HttpStatus.ACCEPTED.value());
		return new ResponseEntity<ResponseStructure<ClientAcept>>(structure, HttpStatus.ACCEPTED);
	}

	public ResponseEntity<ResponseStructure<ClientAcept>> fetchAceptById(int id) {
		ClientAcept db = clientAceptDao.fetchAceptById(id);
		if(db!=null){
		ResponseStructure<ClientAcept> structure=new ResponseStructure<ClientAcept>();
		structure.setData(db);
		structure.setMessage("Admin saved successfully");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<ClientAcept>>(structure, HttpStatus.FOUND);
		}
		else 
			throw new ClientIdNotFoundException(id+"id is not present");
	}
}
