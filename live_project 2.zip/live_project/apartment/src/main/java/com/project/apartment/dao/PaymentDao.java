package com.project.apartment.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Payment;
import com.project.apartment.repo.PaymentRepo;

@Repository
public class PaymentDao {

	@Autowired
	private PaymentRepo paymentRepo;

	public  Payment fetchCard(long card, int cvv) {
		return paymentRepo.fetchCard(card,cvv);
	}
	
}
