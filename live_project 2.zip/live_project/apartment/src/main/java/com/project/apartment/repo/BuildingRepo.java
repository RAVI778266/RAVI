package com.project.apartment.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Admin;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Manager;

public interface BuildingRepo extends JpaRepository<Building,Integer>{
	@Query("select a from Building a where a.building_name=?1")
	List<Building> fetchByBuildingName(String building_name);
//	@Query("update Building a set a.admin=null where a.admin_id=?1")
//	Building updateBuildingByAdmin(Admin db);
	@Query("select a from Building a where a.address.street=?1")
	List<Building> fetchByLocation(String location);
	@Query("select a from Building a where a.admin=?1")
	List<Building> fetchByAdmin(Admin admin);
	@Query("select a from Building a where a.address.city=?1")
	List<Building> findCitys(String city);
	@Query("select distinct(a.address.city) from Building a")
	List<String> findCity();
	@Query("select a from Building a where a.manager=?1")
	Building searchManager(Manager dbmanager);
	
}
