package com.project.apartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Building;
import com.project.apartment.dto.Manager;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.sevice.ManagerService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class ManagerController {

	@Autowired
	private ManagerService managerService;
	
	@PostMapping("/manager")
	public ResponseEntity<ResponseStructure<Manager>> saveManager(@RequestBody Manager manager){
		return managerService.saveManager(manager);
	}
	@GetMapping("/fetchManagerById")
	public ResponseEntity<ResponseStructure<Manager>>  fetchManagerById(@RequestParam int id){
		return managerService.fetchManagerById(id);
	}
	@GetMapping("/fetchManagers")
	public ResponseEntity<ResponseStructure<List<Manager>>>  fetchManagers(){
		return managerService.fetchManagers();
	}
	@GetMapping("/fetchManagerbyExperiance")
	public ResponseEntity<ResponseStructure<List<Manager>>>  fetchManagersByExperiance(@RequestParam int experiance){
		return managerService.fetchManagersByExperiance(experiance);
	}
	@PutMapping("/updateManager")
	public ResponseEntity<ResponseStructure<Manager>>  updateManager(@RequestParam int id,@RequestBody Manager manager){
		return managerService.updateManager(id,manager);
	}
	@DeleteMapping("/deleteManager")
	public ResponseEntity<ResponseStructure<Manager>> deleteManager(@RequestParam int id){
		return managerService.deleteManager(id);
	}
	@GetMapping("/managerLogin")
	public ResponseEntity<ResponseStructure<Manager>> managerLogin(@RequestParam String email,@RequestParam String password){
		return managerService.managerLogin(email, password);
	}
	@PostMapping("/addworkspacebyManager")
	public ResponseEntity<ResponseStructure<Manager>> addWorkSpace(@RequestParam int manager_id,@RequestParam int floor_id,@RequestBody WorkSpace workSpace){
		return managerService.addWorkSpace(manager_id,floor_id,workSpace);
	}
	@GetMapping("/fetchBulidingByManagger")
	public ResponseEntity<ResponseStructure<Building>> fetchBulidingByManagger(@RequestParam int manager_id){
		return managerService.fetchBulidingByManagger(manager_id);
	}
}
