package com.project.apartment.exception;

public class ManagerIdNotFoundException  extends RuntimeException{

	public ManagerIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
