package com.project.apartment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Floor;
import com.project.apartment.sevice.FloorService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class FloorController {
	@Autowired
	private FloorService floorService;
	
	@GetMapping("/fetchfloor")
	public ResponseEntity<ResponseStructure<Floor>> fetchFloor(@RequestParam int id){
		return floorService.fetchFloor(id);
	}
}
