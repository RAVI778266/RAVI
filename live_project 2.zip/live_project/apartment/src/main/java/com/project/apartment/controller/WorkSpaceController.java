package com.project.apartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;
import com.project.apartment.sevice.WorkSpaceService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class WorkSpaceController {
	@Autowired
	private WorkSpaceService workSpaceService;
	
	@PostMapping("/saveWorkSpace")
	public ResponseEntity<ResponseStructure<WorkSpace>> saveWorkSpace(@RequestBody WorkSpace workSpace,@RequestParam int floor_id){
	return workSpaceService.saveWorkSpace(workSpace,floor_id);
	}
	@PostMapping("/saveWorkSpaceByManager")
	public ResponseEntity<ResponseStructure<WorkSpace>> saveWorkSpaceByManager(@RequestBody WorkSpace workSpace,@RequestParam int manager_id){
	return workSpaceService.saveWorkSpaceByManager(workSpace,manager_id);
	}
	@PutMapping("/updateWorkSpace")
	public ResponseEntity<ResponseStructure<WorkSpace>> updateWorkSpace(@RequestBody WorkSpace workSpace,@RequestParam int id){
		return workSpaceService.updateWorkSpace(id,workSpace);
	}
	@DeleteMapping("/deleteWorkSpace")
	public ResponseEntity<ResponseStructure<WorkSpace>> deleteWorkSpace(@RequestParam int id){
		return workSpaceService.deleteWorkSpace(id);
	}
	@GetMapping("/fetchWorkSpaceById")
	public ResponseEntity<ResponseStructure<WorkSpace>> fetchWorkSpaceById(@RequestParam int id){
		return workSpaceService.fetchWorkSpaceById(id);
	}
	@GetMapping("/fetchWorkSpaceByManager")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByManager(@RequestParam int id){
		return workSpaceService.fetchWorkSpaceByManager(id);
	}
	@GetMapping("/fetchWorkSpaces")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaces(){
		return workSpaceService.fetchWorkSpaces();
	}
	@GetMapping("/fetchWorkSpaceByBuilding")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByBuilding(@RequestParam int id ){
		return workSpaceService.fetchWorkSpaceByBuilding(id);
	}
	@GetMapping("/fetchWorkSpaceByType")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByType(@RequestParam WorkSpaceEnum type ){
		return workSpaceService.fetchWorkSpaceByType(type);
	}
	@GetMapping("/fetchWorkSpaceByLocation")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByLocation(@RequestParam String location ){
		return workSpaceService.fetchWorkSpaceByLocation(location);
	}
	@GetMapping("/fetchWorkSpaceByCost")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByCost(@RequestParam double cost){
		return workSpaceService.fetchWorkSpaceByCost(cost);
	}
	@GetMapping("/fetchWorkSpaceByCapacity")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> fetchWorkSpaceByCapacity(@RequestParam String capacity){
		return workSpaceService.fetchWorkSpaceByCapacity(capacity);
	}
	@GetMapping("/filterWorkSpace")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> filterWorkSpace(@RequestParam Double price,@RequestParam Double price1,@RequestParam WorkSpaceEnum type,@RequestParam int capacity,@RequestParam int capacity1){
		return workSpaceService.filterWorkSpace(price,price1,type,capacity,capacity1);
	}
	@GetMapping("/filterWorkSpacewithoutType")
	public ResponseEntity<ResponseStructure<List<WorkSpace>>> filterWorkSpace(@RequestParam Double price,@RequestParam Double price1,@RequestParam int capacity,@RequestParam int capacity1){
		return workSpaceService.filterWorkSpace(price,price1,capacity,capacity1);
	}
}
