package com.project.apartment.dao;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.ClientBooking;
import com.project.apartment.repo.ClientBookingRepo;
@RestController
public class ClientBookingDao {
	@Autowired
	private  ClientBookingRepo bookingRepo;

	public ClientBooking saveBooking(ClientBooking booking) {
		return bookingRepo.save(booking);
	}

	public ClientBooking fetchById(int clientBooking_id) {
		Optional<ClientBooking> db=bookingRepo.findById(clientBooking_id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}

	public void deleteClientBooking(List<ClientBooking> bookings) {
		bookingRepo.deleteAll(bookings);
	}
	
//	public List<ClientBooking> addBooking(List<Integer> id) {
//		List<ClientBooking> db;
//		return  null;
//	}
	
}
