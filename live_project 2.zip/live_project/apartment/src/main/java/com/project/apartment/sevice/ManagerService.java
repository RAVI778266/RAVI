package com.project.apartment.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.AddressDao;
import com.project.apartment.dao.BuildingDao;
import com.project.apartment.dao.FloorDao;
import com.project.apartment.dao.ManagerDao;
import com.project.apartment.dao.WorkSpaceDao;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Floor;
import com.project.apartment.dto.Manager;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.exception.BuildingNotFoundException;
import com.project.apartment.exception.FloorIdNotFoundException;
import com.project.apartment.exception.ManagerEmailNotFoundException;
import com.project.apartment.exception.ManagerIdNotFoundException;
import com.project.apartment.exception.ManagerPasswordNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class ManagerService {

	@Autowired
	private ManagerDao managerDao;
	@Autowired
	private BuildingDao buildingDao;
	@Autowired
	private AddressDao addressDao;
	@Autowired
	private FloorDao floorDao;
	@Autowired
	private WorkSpaceDao workSpaceDao;
	public ResponseEntity<ResponseStructure<Manager>> saveManager(Manager manager){
		Manager dbmanager=managerDao.saveManager(manager);
		ResponseStructure<Manager> structure=new ResponseStructure<>();
		structure.setData(dbmanager);
		structure.setMessage("Manager saved successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Manager>> fetchManagerById(int id) {
		Manager dbmanager=managerDao.fetchManger(id);
		if(dbmanager != null) {
		ResponseStructure<Manager> structure=new ResponseStructure<>();
		structure.setData(dbmanager);
		structure.setMessage("Manager fetch successfully");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.FOUND);
		}
		else 
			throw new ManagerIdNotFoundException(id+" Manager_id not Found");
	}

	public ResponseEntity<ResponseStructure<List<Manager>>> fetchManagers() {
		List<Manager> dbmanager=managerDao.fetchMangers();
		if(!dbmanager.isEmpty()) {
		ResponseStructure<List<Manager>> structure=new ResponseStructure<>();
		structure.setData(dbmanager);
		structure.setMessage("Manager fetch successfully");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<Manager>>>(structure, HttpStatus.FOUND);
		}
		else 
			throw new ManagerIdNotFoundException("Sorry No Manager is pressent");
	}

	public ResponseEntity<ResponseStructure<List<Manager>>> fetchManagersByExperiance(int experiance) {
		List<Manager> dbmanager=managerDao.fetchManagersByExperiance(experiance);
		if(!dbmanager.isEmpty()) {
		ResponseStructure<List<Manager>> structure=new ResponseStructure<>();
		structure.setData(dbmanager);
		structure.setMessage("Manager fetch successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<List<Manager>>>(structure, HttpStatus.CREATED);
		}
		else 
			throw new ManagerIdNotFoundException("Sorry No Manager Found with  Experiance "+experiance+" years ");
	}

	public ResponseEntity<ResponseStructure<Manager>> updateManager(int id, Manager manager) {
		Manager dbmanager=managerDao.fetchManger(id);
		if(dbmanager != null) {
			if(manager.getName()!=null) {
				dbmanager.setName(manager.getName());
			}
			if(manager.getPhone()!=0) {
				dbmanager.setPhone(manager.getPhone());
			}
			if(manager.getEmail()!=null) {
				dbmanager.setEmail(manager.getEmail());
			}
			if(manager.getExperiance()!=0) {
				dbmanager.setExperiance(manager.getExperiance());
			}
			if(manager.getPwd()!=null) {
				dbmanager.setPwd(manager.getPwd());
			}
			if(manager.getGender()!=null) {
				dbmanager.setGender(manager.getGender());
			}
			if(manager.getAddress()!=null) {
			dbmanager.setAddress(addressDao.saveAddress(manager.getAddress(),dbmanager.getAddress().getId()));
			}
		ResponseStructure<Manager> structure=new ResponseStructure<>();
		structure.setData(managerDao.saveManager(dbmanager));
		structure.setMessage("Manager fetch successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.CREATED);
		}
		else 
			throw new ManagerIdNotFoundException(id+"Manager_id Not Found ");
	}

	public ResponseEntity<ResponseStructure<Manager>> deleteManager(int id) {
		Manager dbmanager=managerDao.fetchManger(id);
		if(dbmanager != null) {
			buildingDao.dispatchManager(dbmanager);
			managerDao.deleteManager(dbmanager);
		ResponseStructure<Manager> structure=new ResponseStructure<>();
		structure.setData(dbmanager);
		structure.setMessage("Manager delete successfully");
		structure.setStatus(HttpStatus.ACCEPTED.value());
		return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.ACCEPTED);
		}
		else 
			throw new ManagerIdNotFoundException(id+" Manager_id not Found");
	}

	public ResponseEntity<ResponseStructure<Manager>> managerLogin(String email, String password) {
		Manager dbemail=managerDao.FetchByEmail(email);
		if(dbemail!=null) {
			Manager login=managerDao.managerLogin(email,password);
			if(login!=null) {
				ResponseStructure<Manager> structure=new ResponseStructure<>();
				structure.setData(login);
				structure.setMessage("Manager login successfully");
				structure.setStatus(HttpStatus.FOUND.value());
				return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.FOUND);
			}
			else 
				throw new ManagerPasswordNotFoundException(password+" Password not Found");
		}
		else 
			throw new ManagerEmailNotFoundException(email+" Email not Found");
	}

	public ResponseEntity<ResponseStructure<Manager>> addWorkSpace(int manager_id, int floor_id, WorkSpace workSpace) {
		Manager dbmanager=managerDao.fetchManger(manager_id);
		if(dbmanager != null) {
		Building dbbuilding= buildingDao.searchManager(dbmanager);
		if(dbbuilding!=null) {
			Floor f=buildingDao.searchFloor(dbbuilding,floor_id);
			if(f!=null) {
				List<WorkSpace> work=f.getWorkspaces();
				work.add(workSpaceDao.saveWorkSpace(workSpace));
				f.setWorkspaces(work);
				floorDao.saveFloor(f);
				ResponseStructure<Manager> structure=new ResponseStructure<>();
				structure.setData(dbmanager);
				structure.setMessage("add successfully");
				structure.setStatus(HttpStatus.CREATED.value());
				return new ResponseEntity<ResponseStructure<Manager>>(structure, HttpStatus.CREATED);
			}
			else 
				throw new FloorIdNotFoundException(floor_id+" floor_id not Found");
		}
		else 
			throw new BuildingNotFoundException(" Building not Found");
		}
		else 
			throw new ManagerIdNotFoundException( manager_id+" Manager_id not Found");
	}

	public ResponseEntity<ResponseStructure<Building>> fetchBulidingByManagger(int manager_id) {
		Manager dbmanager=managerDao.fetchManger(manager_id);
		if(dbmanager != null) {
			Building dbbuilding=buildingDao.searchManager(dbmanager);
		if(dbbuilding!=null) {
		ResponseStructure<Building> structure=new ResponseStructure<>();
		structure.setData(dbbuilding);
		structure.setMessage("Manager fetch successfully");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<Building>>(structure, HttpStatus.FOUND);
		}
			else
				throw new BuildingNotFoundException("building not found");
		}
		else 
			throw new ManagerIdNotFoundException(manager_id+" Manager_id not Found");
	}
}