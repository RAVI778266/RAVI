package com.project.apartment.controller;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Client;
import com.project.apartment.dto.ClientBooking;
//import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;
import com.project.apartment.sevice.ClientService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class ClientController {

	@Autowired
	private ClientService clientService;
	
	@PostMapping("/client")
	public ResponseEntity<ResponseStructure<Client>> saveClient(@RequestBody Client client){
		return clientService.saveClient(client);
	}
	@PutMapping("/clientUpdate")
	public ResponseEntity<ResponseStructure<Client>> clientUpdate(@RequestBody Client client,@RequestParam int client_id){
		return clientService.clientUpdate(client,client_id);
	}
	@GetMapping("/fetchClient")
	public ResponseEntity<ResponseStructure<Client>> fetchClient(@RequestParam int client_id){
		return clientService.fetchClient(client_id);
	}
	@DeleteMapping("/deleteClient")
	public ResponseEntity<ResponseStructure<Client>> deleteClient(@RequestParam int client_id){
		return clientService.deleteClient(client_id);
	}
	@GetMapping("/clientLogin")
	public ResponseEntity<ResponseStructure<Client>> clientLogin(@RequestParam String email ,@RequestParam String password){
		return clientService.clientLogin(email,password);
	}
	
	/*@PostMapping("/addBooking")
	public ResponseEntity<ResponseStructure<Client>> addBooking(@RequestParam List<Integer> id,@RequestParam int client_id){
		return clientService.addBooking(id,client_id);
	}*/
	@PostMapping("/addBooking")
	public ResponseEntity<ResponseStructure<ClientBooking>> addBooking(@RequestParam int workSpace_id,@RequestParam int client_id,@RequestBody ClientBooking clientBooking,@RequestParam WorkSpaceEnum type ){
		return clientService.addBooking(workSpace_id,client_id,clientBooking,type);
	}
} 