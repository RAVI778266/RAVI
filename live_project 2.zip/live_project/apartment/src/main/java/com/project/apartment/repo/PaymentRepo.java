package com.project.apartment.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Payment;

public interface PaymentRepo extends  JpaRepository<Payment,Integer>{
	@Query("select a from Payment a where card=?1 and cvv=?2")
	public Payment fetchCard(long card ,int cvv);

}
