package com.project.apartment.exception;

public class ClientIdNotFoundException extends RuntimeException{

	public ClientIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
