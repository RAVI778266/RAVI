package com.project.apartment.sevice;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.FloorDao;
import com.project.apartment.dto.Floor;
import com.project.apartment.exception.FloorIdNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class FloorService {
	@Autowired
	private FloorDao floorDao;

	public ResponseEntity<ResponseStructure<Floor>> fetchFloor(int id) {
		Floor f=floorDao.fetchFloor(id);
		if(f!=null) {
			ResponseStructure<Floor> structure=new ResponseStructure<>();
			structure.setData(f);
			structure.setMessage("Floor fetch successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Floor>>(structure, HttpStatus.FOUND);	
		}
		else
			throw new FloorIdNotFoundException(id+"Floor_id not found");
	}
	
}
