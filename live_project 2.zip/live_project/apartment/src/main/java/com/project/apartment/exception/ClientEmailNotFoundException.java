package com.project.apartment.exception;

public class ClientEmailNotFoundException extends RuntimeException {

	public ClientEmailNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
