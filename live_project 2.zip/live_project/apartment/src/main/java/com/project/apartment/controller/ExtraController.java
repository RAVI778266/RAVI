package com.project.apartment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.Building;
import com.project.apartment.sevice.ExtraService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class ExtraController {
	@Autowired
	private ExtraService extraService;
	
	@PostMapping("payment")
	public ResponseEntity<ResponseStructure<String>> payment(@RequestParam int client_id,@RequestParam int clientBooking_id,@RequestParam String payment){
		return extraService.payment(client_id, clientBooking_id, payment);
	}
	@GetMapping("ratting")
	public ResponseEntity<ResponseStructure<Building>> ratting(@RequestParam int ratting,@RequestParam int building_id){
		return extraService.ratting(ratting,building_id);
	}
}
