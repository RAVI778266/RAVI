package com.project.apartment.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;

public interface WorkSpaceRepo  extends JpaRepository<WorkSpace, Integer>{
	@Query("select a from WorkSpace a where a.type=?1")
	List<WorkSpace> fetchWorkSpaceByType(WorkSpaceEnum type);
	@Query("select a from WorkSpace a where a.pricePerDay=?1")
	List<WorkSpace> fetchWorkSpaceByCost(double cost);
	@Query("select a from WorkSpace a where a.squarefeet=?1")
	List<WorkSpace> fetchWorkSpaceByCapacity(String capacity);
	@Query("select a from WorkSpace a where a.type=?1 and id=?2")
	List<WorkSpace> fetchWorkSpaceByTypeAndId(WorkSpaceEnum type, int workSpace_id);
	@Query("select a from WorkSpace a where a.pricePerDay between ?1 and ?2 and a.type in(?3) and a.capacity between ?4 and ?5")
	List<WorkSpace> filterWorkSpace(Double price,Double price1, WorkSpaceEnum type, int four ,int five);
	@Query("select a from WorkSpace a where a.pricePerDay between ?1 and ?2 and a.capacity between ?3 and ?4")
	List<WorkSpace> filterWorkSpace(Double price,Double price1, int three ,int four);

}
