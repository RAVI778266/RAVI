package com.project.apartment.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Building;
import com.project.apartment.dto.Client;
import com.project.apartment.dto.Floor;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;
import com.project.apartment.repo.BuildingRepo;
import com.project.apartment.repo.FloorRepo;
import com.project.apartment.repo.WorkSpaceRepo;

@Repository
public class WorkSpaceDao {
	@Autowired
	private WorkSpaceRepo workSpaceRepo;
	@Autowired
	private BuildingRepo buildingRepo;

	public WorkSpace saveWorkSpace(WorkSpace workSpace) {
		return workSpaceRepo.save(workSpace);
	}

	public WorkSpace FetchWorkSpaceById(int id) {
		Optional<WorkSpace> db=workSpaceRepo.findById(id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}

	public void deleteWorkSpace(WorkSpace dbwork) {
		 WorkSpace db = dbwork;
		workSpaceRepo.delete(dbwork);
	}

	public List<WorkSpace> fetchWorkSpaces() {
		return workSpaceRepo.findAll();
	}

	public List<WorkSpace> fetchWorkSpaceByType(WorkSpaceEnum type) {
		return workSpaceRepo.fetchWorkSpaceByType(type);
	}

	public List<WorkSpace> fetchWorkSpaceByLocation(String location) {
		List<Building> bdb=buildingRepo.fetchByLocation(location);
		List<Floor> fdb = null;
		for(Building i:bdb) {
			fdb.addAll(i.getFloors());
		}
		List<WorkSpace> db=null;
		for(Floor i:fdb) {
			db.addAll(i.getWorkspaces());
		}
		return db;
	}

	public List<WorkSpace> fetchWorkSpaceByCost(double cost) {
		return workSpaceRepo.fetchWorkSpaceByCost(cost);
	}

	public List<WorkSpace> fetchWorkSpaceByCapacity(String capacity) {
		return workSpaceRepo.fetchWorkSpaceByCapacity(capacity);
	}

	public WorkSpace saveworkSpace(int workSpace_id, WorkSpaceEnum type) {
		List<WorkSpace> w=workSpaceRepo.fetchWorkSpaceByTypeAndId(type,workSpace_id);
		if(!w.isEmpty()) {
			return w.get(0);
		}
		return null;
	}

	public List<WorkSpace> filterWorkSpace(Double price, Double price1, WorkSpaceEnum type, int capacity, int capacity1) {
		return workSpaceRepo.filterWorkSpace(price,price1,type,capacity,capacity1);
	}

	public List<WorkSpace> filterWorkSpace(Double price, Double price1, int capacity, int capacity1) {
		return workSpaceRepo.filterWorkSpace(price,price1,capacity,capacity1);
	}

	public void removeClient(Client db) {
		List<WorkSpace> dbw = workSpaceRepo.findAll();
		for(WorkSpace i:dbw) {
			i.getClients().remove(db);
			workSpaceRepo.save(i);
		}
		
	}

	public List<WorkSpace> fetchWorkSpaceByManager(List<Floor> f) {
		List<WorkSpace> dbw =new ArrayList<WorkSpace>();
		for(Floor i:f) {
			dbw.addAll(i.getWorkspaces());
		}
		return dbw;
	}
}
