package com.project.apartment.exception;

public class AdminDoorNoNotFound extends RuntimeException{

	public AdminDoorNoNotFound(String message ) {
		super(message);
	}

}
