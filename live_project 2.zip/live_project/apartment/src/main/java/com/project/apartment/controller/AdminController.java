package com.project.apartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.clone.AdminClone;
import com.project.apartment.dto.Admin;
import com.project.apartment.sevice.AdminService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/admin")
	public ResponseEntity<ResponseStructure<AdminClone>> saveAdmin(@RequestBody Admin admin){
		return adminService.saveAdmin(admin);
	}
	@GetMapping("/fetchByName")
	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByName(@RequestParam String name){
		return adminService.fetchByName(name);
	}
	@PutMapping("/updateAdmin")
	public ResponseEntity<ResponseStructure<Admin>> updateAdmin(@RequestBody Admin admin,@RequestParam int id){
		return adminService.updateAdmin(admin,id);
		
	}
	@DeleteMapping("/deleteAdmin")
	public ResponseEntity<ResponseStructure<Admin>> deleteAdmin(@RequestParam int id){
		return adminService.deleteAdmin(id);
	}	
	@GetMapping("/fetchAdminId")
	public ResponseEntity<ResponseStructure<Admin>> fetchById(@RequestParam int id){
		return adminService.fetchById(id);
	}
	@GetMapping("/fetchByEmail")
	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByEmail(@RequestParam String email){
		return adminService.fetchByEmail(email);
	}
	@GetMapping("/fetchByDoorNo")
	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByDoorNo(@RequestParam String doorno){
		return adminService.fetchByDoorNo(doorno);
	}
	@GetMapping("/adminLogin")
	public ResponseEntity<ResponseStructure<Admin>> adminLogin(@RequestParam String email,@RequestParam String  password){
		return adminService.adminLogin(email, password);
	}
}
