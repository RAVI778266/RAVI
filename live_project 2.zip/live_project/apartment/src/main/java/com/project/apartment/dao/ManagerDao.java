package com.project.apartment.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Building;
import com.project.apartment.dto.Manager;
import com.project.apartment.repo.BuildingRepo;
import com.project.apartment.repo.ManagerRepo;

@Repository
public class ManagerDao {

	@Autowired
	private ManagerRepo managerRepo;
	@Autowired
	private BuildingRepo buildingRepo;
	
	public Manager saveManager(Manager manager) {
		return managerRepo.save(manager);
	}

	public Manager fetchManger(int manager_id) {
		Optional<Manager> db=managerRepo.findById(manager_id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}

	public List<Manager> fetchMangers() {
		List<Building> db=buildingRepo.findAll();
		List<Manager> mdb=new ArrayList<Manager>();
		List<Manager> msdb = managerRepo.findAll();
//		for(Building i: db) {
//			if( i.getManager()!=null) {
//			for(Manager j:msdb) {
//				if(!i.getManager().equals(j))) {
//					
//				}
//			}
//			}
//		}
		for(Manager j:msdb) {
			for(Building i: db) {
				if( i.getManager()!=null) {
					if(i.getManager().equals(j)) {
						mdb.add(j);
					}
				}
			}
		}
		msdb.removeAll(mdb);
		return msdb;
	}

	public List<Manager> fetchManagersByExperiance(int experiance) {
		return managerRepo.fetchManagersByExperiance(experiance);
	}

	public void deleteManager(Manager dbmanager) {
		managerRepo.delete(dbmanager);
	}

	public Manager FetchByEmail(String email) {
		return managerRepo.fetchEmail(email);
	}

	public Manager managerLogin(String email, String password) {
		return managerRepo.managerLogin(email, password);
	}
}
