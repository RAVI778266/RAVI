package com.project.apartment.exception;

public class CardNotFound extends RuntimeException{
	
 public CardNotFound(String message) {
	 super(message);
	 
 }
}
