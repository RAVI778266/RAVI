package com.project.apartment.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Floor;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.repo.FloorRepo;
import com.project.apartment.repo.WorkSpaceRepo;

@Repository
public class FloorDao {
	@Autowired
	private FloorRepo floorRepo;
	@Autowired
	private WorkSpaceRepo workSpaceRepo;
	
	public Floor fetchFloor(int id) {
		Optional<Floor> f=floorRepo.findById(id);
		if(f.isPresent()) {
			return f.get();
		}
		return null;
	}

	public Floor saveFloor(Floor f) {
		return floorRepo.save(f);
	}

	public void removeWorkspace(WorkSpace dbwork) {
		List<Floor> floor = floorRepo.findAll();
		for(Floor i:floor) {
			i.getWorkspaces().remove(dbwork);		
			i.setWorkspaces(i.getWorkspaces());
			
		}
	}

	public void deleteFloor(List<Floor> floors) {
		for(Floor i:floors) {
			for(WorkSpace j:i.getWorkspaces()) {
				workSpaceRepo.delete(j);	
			}
		}
		floorRepo.deleteAll(floors);
	}
	
	

}
