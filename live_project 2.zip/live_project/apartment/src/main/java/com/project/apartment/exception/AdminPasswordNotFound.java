package com.project.apartment.exception;

public class AdminPasswordNotFound extends RuntimeException{

	public AdminPasswordNotFound(String message) {
		super(message);
	}

}
