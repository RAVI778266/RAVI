package com.project.apartment.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
@Data
@Entity
public class Floor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int floor_Number;
	@OneToMany(cascade = CascadeType.ALL)
	private List<WorkSpace>workspaces;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFloor_Number() {
		return floor_Number;
	}
	public void setFloor_Number(int floor_Number) {
		this.floor_Number = floor_Number;
	}
	public List<WorkSpace> getWorkspaces() {
		return workspaces;
	}
	public void setWorkspaces(List<WorkSpace> workspaces) {
		this.workspaces = workspaces;
	}
	

}
