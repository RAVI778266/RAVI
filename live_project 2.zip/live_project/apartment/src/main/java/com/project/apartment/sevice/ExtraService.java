package com.project.apartment.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.BuildingDao;
import com.project.apartment.dao.ClientBookingDao;
import com.project.apartment.dao.ClientDao;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Client;
import com.project.apartment.dto.ClientBooking;
import com.project.apartment.exception.BuildingNotFoundException;
import com.project.apartment.exception.ClientBookingIdNotFoundException;
import com.project.apartment.exception.ClientIdNotFoundException;
import com.project.apartment.util.ResponseStructure;
@Service
public class ExtraService {
	@Autowired
	private ClientDao clientDao;
	@Autowired
	private ClientBookingDao clientBookingDao;
	@Autowired
	private BuildingDao buildingDao;
	
	public ResponseEntity<ResponseStructure<String>> payment(int client_id, int clientBooking_id, String payment) {
		Client ci=clientDao.fetchById(client_id);
		if(ci!=null) {
			ClientBooking cb=clientBookingDao.fetchById(clientBooking_id);
			if(cb!=null) {
				ResponseStructure<String> structure =new ResponseStructure<String>();
				structure.setData("Your payment of  "+payment+" done ");
				structure.setMessage("workSpace save");
				structure.setStatus(HttpStatus.ACCEPTED.value());
				return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.ACCEPTED);
			}
			else
				throw new ClientIdNotFoundException(client_id+" Client_id is not present");
		}
		else
			throw new ClientBookingIdNotFoundException(clientBooking_id+" Client_id is not present");
	
	}

	public ResponseEntity<ResponseStructure<Building>> ratting(int ratting, int building_id) {
		Building db=buildingDao.fetchBuilding(building_id);
		if(db!=null) {
			db.setRatings(ratting);
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.saveBuilding(db));
			structure.setMessage("Building saved successfully......");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure, HttpStatus.CREATED);
		}
		else
			throw new BuildingNotFoundException(building_id +"building_id not present");
	}

}
