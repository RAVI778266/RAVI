package com.project.apartment.exception;

public class WorkSpaceNotFoundException extends RuntimeException {

	public WorkSpaceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
