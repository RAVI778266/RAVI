package com.project.apartment.exception;

public class ManagerPasswordNotFoundException extends RuntimeException{

	public ManagerPasswordNotFoundException(String message) {
		super(message);
	}
	

}
