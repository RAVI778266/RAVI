package com.project.apartment.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.AddressDao;
import com.project.apartment.dao.ClientBookingDao;
import com.project.apartment.dao.ClientDao;
import com.project.apartment.dao.WorkSpaceDao;
import com.project.apartment.dto.Client;
import com.project.apartment.dto.ClientBooking;
import com.project.apartment.dto.WorkSpace;
import com.project.apartment.enums.WorkSpaceEnum;
import com.project.apartment.exception.ClientBookingIdNotFoundException;
import com.project.apartment.exception.ClientEmailNotFoundException;
import com.project.apartment.exception.ClientIdNotFoundException;
import com.project.apartment.exception.ClientPasswordNotFoundException;
import com.project.apartment.exception.WorkSpaceIdNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class ClientService {

	@Autowired
	private ClientDao clientDao;
	@Autowired
	private ClientBookingDao bookingDao;
	@Autowired
	private WorkSpaceDao workSpaceDao;
	@Autowired
	private AddressDao addressDao;
	@Autowired
	private ClientBookingDao clientBookingDao;
	
	public ResponseEntity<ResponseStructure<Client>> saveClient(Client client){
		Client dbclient=clientDao.saveClient(client);
		ResponseStructure<Client> structure=new ResponseStructure<>();
		structure.setData(dbclient);
		structure.setMessage("Client saved successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<ClientBooking>> addBooking(int workSpace_id, int client_id,ClientBooking clientBooking, WorkSpaceEnum type) {
		Client db=clientDao.fetchById(client_id);
		if(db!=null) {
			List<ClientBooking> dbc=db.getBookings();
			dbc.add(clientBooking);
			db.setBookings(dbc);
			WorkSpace w=workSpaceDao.saveworkSpace(workSpace_id,type);
			if(w!=null) {
				ClientBooking dbb=bookingDao.saveBooking(clientBooking);
				clientDao.saveClient(db);
				List<Client> wb=w.getClients();
				wb.add(db);
				w.setClients(wb);
				workSpaceDao.saveWorkSpace(w);
				ResponseStructure<ClientBooking> structure=new ResponseStructure<>();
				structure.setData(dbb);
				structure.setMessage("Client booking successfully");
				structure.setStatus(HttpStatus.CREATED.value());
				return new ResponseEntity<ResponseStructure<ClientBooking>>(structure, HttpStatus.CREATED);
		}
			else
				throw new WorkSpaceIdNotFoundException(workSpace_id +"workSpace id not found");
		}
		else
			throw new ClientIdNotFoundException(client_id+" client_id not found");
		
	}

	public ResponseEntity<ResponseStructure<Client>> clientUpdate(Client client, int client_id) {
		Client db=clientDao.fetchById(client_id);
		if(db!=null) {
			if(client.getName()!=null) {
				db.setName(client.getName());
			}
			if(client.getAddress()!=null) {
			db.setAddress(addressDao.saveAddress(client.getAddress(),db.getAddress().getId()));
			}
			if(client.getAge()!=null) {
				db.setAge(client.getAge());
			}
			if(client.getBookings()!=null) {
				db.setBookings(client.getBookings());
			}
			if(client.getEmail()!=null && !client.getEmail().equals(db.getEmail())) {
				db.setEmail(client.getEmail());
			}
			if(client.getGender()!=null) {
				db.setGender(client.getGender());
			}
			if(client.getPhone()!=0) {
				db.setPhone(client.getPhone());
			}
			if(client.getId_proof()!=null) {
				db.setId_proof(client.getId_proof());
			}
			if(client.getPwd()!=null) {
				db.setPwd(client.getPwd());
			}
			ResponseStructure<Client> structure=new ResponseStructure<>();
			structure.setData(clientDao.saveClient(db));
			structure.setMessage("Client booking successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.CREATED);
		}
		else
			throw new ClientIdNotFoundException(client_id+" client_id not found");
	}

	public ResponseEntity<ResponseStructure<Client>> fetchClient(int client_id) {
		Client db=clientDao.fetchById(client_id);
		if(db!=null) {
			ResponseStructure<Client> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Client booking successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.CREATED);
		}
		else
			throw new ClientIdNotFoundException(client_id+" client_id not found");
	}

	public ResponseEntity<ResponseStructure<Client>> deleteClient(int client_id) {
		Client db=clientDao.fetchById(client_id);
		if(db!=null) {
			workSpaceDao.removeClient(db);
			if(!db.getBookings().isEmpty()) {
			clientBookingDao.deleteClientBooking(db.getBookings());
			}
			clientDao.deleteClient(db);
			ResponseStructure<Client> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Client booking successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.FOUND);
		}
		else
			throw new ClientIdNotFoundException(client_id+" client_id not found");
	}

	public ResponseEntity<ResponseStructure<Client>> clientLogin(String email, String password) {
		Client db=clientDao.fetchEmail(email);
		if(db!=null) {
			Client login=clientDao.clientLogin(email,password);
			if(login!=null) {
				ResponseStructure<Client> structure=new ResponseStructure<>();
				structure.setData(login);
				structure.setMessage("Client login successfully");
				structure.setStatus(HttpStatus.FOUND.value());
				return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.FOUND);
			}
			else
				throw new ClientPasswordNotFoundException(password+" Password not found");
		}
		else
			throw new ClientEmailNotFoundException(email+" Email not found");
	}

	/*public ResponseEntity<ResponseStructure<Client>> addBooking(List<Integer> id, int client_id) {
		Client db=clientDao.fetchById(client_id);
		if(db!=null) {
			List<ClientBooking> dbb=db.getBookings();
			dbb.add(bookingDao.addBooking(id));
			db.setBookings(dbb);
			ResponseStructure<Client> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Client booking successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Client>>(structure, HttpStatus.CREATED);	
		}
		return null;
	}*/
}
