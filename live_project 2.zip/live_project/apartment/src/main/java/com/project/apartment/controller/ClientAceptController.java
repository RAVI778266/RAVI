package com.project.apartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.apartment.dto.ClientAcept;
import com.project.apartment.sevice.ClientAceptService;
import com.project.apartment.util.ResponseStructure;

@RestController
public class ClientAceptController {

	@Autowired
	private ClientAceptService clientAceptService;
	
	@PostMapping("/status")
	public ResponseEntity<ResponseStructure<ClientAcept>> save(@RequestBody ClientAcept clientAcept){
		return clientAceptService.save(clientAcept);	
	}
	@GetMapping("/fetchAceptById")
	public ResponseEntity<ResponseStructure<ClientAcept>> fetchAceptById(@RequestParam int id){
		return clientAceptService.fetchAceptById(id);	
	}
	@PutMapping("/addStatus")
	public ResponseEntity<ResponseStructure<ClientAcept>> addStatus(@RequestParam String status,@RequestParam int id){
		return clientAceptService.addStatus(status,id);	
	}
	@GetMapping("/fetchAceptManager")
	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptManager(@RequestParam int id){
		return clientAceptService.fetchAceptManager(id);	
	}
	@GetMapping("/fetchAceptAdmin")
	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptAdmin(@RequestParam int id){
		return clientAceptService.fetchAceptAdmin(id);	
	}
	@GetMapping("/fetchAceptClient")
	public ResponseEntity<ResponseStructure<List<ClientAcept>>> fetchAceptClient(@RequestParam int id){
		return clientAceptService.fetchAceptClient(id);	
	}
	@DeleteMapping("/deleteAcept")
	public ResponseEntity<ResponseStructure<ClientAcept>> deleteAcept(@RequestParam int id){
		return clientAceptService.deleteAcept(id);	
	}
	
}
