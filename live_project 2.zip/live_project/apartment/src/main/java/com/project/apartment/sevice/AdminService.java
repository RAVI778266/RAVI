package com.project.apartment.sevice;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.clone.AdminClone;
import com.project.apartment.dao.AddressDao;
import com.project.apartment.dao.AdminDao;
import com.project.apartment.dao.BuildingDao;
import com.project.apartment.dto.Admin;
import com.project.apartment.dto.Manager;
import com.project.apartment.exception.AdminDoorNoNotFound;
import com.project.apartment.exception.AdminEmailNotFound;
import com.project.apartment.exception.AdminIdNotFound;
import com.project.apartment.exception.AdminPasswordNotFound;
import com.project.apartment.util.ResponseStructure;
@Service
public class AdminService {
	
	@Autowired
	private AdminDao adminDao;
	@Autowired
	private BuildingDao buildingDao;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private AddressDao addressDao;
	public ResponseEntity<ResponseStructure<AdminClone>> saveAdmin(Admin admin){		
		Admin dbadmin=adminDao.saveAdmin(admin);
//		AdminClone clone=new AdminClone();
//		clone.setId(dbadmin.getId());
//		clone.setEmail(dbadmin.getEmail());
//		clone.setName(dbadmin.getName());
//		clone.setPhone(dbadmin.getPhone());
		AdminClone clone =modelMapper.map(dbadmin, AdminClone.class);
		
		ResponseStructure<AdminClone> structure=new ResponseStructure<>();
		structure.setData(clone);
		structure.setMessage("Admin saved successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<AdminClone>>(structure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByName(String name) {
		List<Admin> db=adminDao.fetchByName(name);
		if(!db.isEmpty()) {
			ResponseStructure<List<Admin>> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Admin Fetch successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Admin>>>(structure, HttpStatus.FOUND);	
		}
		else 
			throw new AdminIdNotFound(name+" name not found");
		
	}

	public ResponseEntity<ResponseStructure<Admin>> updateAdmin(Admin admin, int id) {
		Admin dbadmin=adminDao.fetchAdmin(id);
		if(dbadmin != null) {
			if(admin.getName()!=null) {
				dbadmin.setName(admin.getName());
			}
			if(admin.getPhone()!=0) {
				dbadmin.setPhone(admin.getPhone());
			}
			if(admin.getEmail()!=null) {
				dbadmin.setEmail(admin.getEmail());
			}
			if(admin.getPwd()!=null) {
				dbadmin.setPwd(admin.getPwd());
			}
			if(admin.getGender()!=null) {
				dbadmin.setGender(admin.getGender());
			}
			if(admin.getAddress()!=null) {
				dbadmin.setAddress(addressDao.saveAddress(admin.getAddress(),dbadmin.getAddress().getId()));
			}
			ResponseStructure<Admin> structure=new ResponseStructure<>();
			structure.setData(adminDao.saveAdmin(dbadmin));
			structure.setMessage("Admin update successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Admin>>(structure, HttpStatus.CREATED);	
		}
		else 
			throw new AdminIdNotFound(id +" id not found");
		
	}

	public ResponseEntity<ResponseStructure<Admin>> deleteAdmin(int id) {
		Admin db =adminDao.fetchAdmin(id);
		if(db!=null) {
			buildingDao.adminAsNull(db);
//			buildingDao.deleteBuilding(null)
			ResponseStructure<Admin> structure=new ResponseStructure<>();
			structure.setData(adminDao.deleteAdmin(db));
			structure.setMessage("Admin delete successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Admin>>(structure, HttpStatus.FOUND);	
		}
		else 
			throw new AdminIdNotFound(id +" id not found");
			}

	public ResponseEntity<ResponseStructure<Admin>> fetchById(int id) {
		Admin db =adminDao.fetchAdmin(id);
		if(db!=null) {
			ResponseStructure<Admin> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Admin delete successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Admin>>(structure, HttpStatus.FOUND);	
		}
		else 
			throw new AdminIdNotFound(id +" id not found");	
	}

	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByEmail(String email) {
		List<Admin> db=adminDao.fetchByEmails(email);
		if(!db.isEmpty()) {
			ResponseStructure<List<Admin>> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Admin saved successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<List<Admin>>>(structure, HttpStatus.FOUND);	
		}
		else 
			throw new AdminEmailNotFound(email+" name not found");
	}

	public ResponseEntity<ResponseStructure<List<Admin>>> fetchByDoorNo(String doorno) {
		List<Admin> db=adminDao.fetchByDoorNo(doorno);
		if(!db.isEmpty()) {
			ResponseStructure<List<Admin>> structure=new ResponseStructure<>();
			structure.setData(db);
			structure.setMessage("Admin saved successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<List<Admin>>>(structure, HttpStatus.FOUND);	
		}
		else 
			throw new AdminDoorNoNotFound(doorno+" name not found");
	}

	public ResponseEntity<ResponseStructure<Admin>> adminLogin(String email, String password) {
		Admin db=adminDao.fetchByEmail(email);
		if(db!=null) {
			Admin login=adminDao.adminLogin(email,password);
			if(login!=null) {
				ResponseStructure<Admin> structure=new ResponseStructure<>();
				structure.setData(login);
				structure.setMessage("Admin login successfully");
				structure.setStatus(HttpStatus.CREATED.value());
				return new ResponseEntity<ResponseStructure<Admin>>(structure, HttpStatus.FOUND);	
			}
			else {
				throw new AdminPasswordNotFound(password+" password invalid");
			}
		}
		else 
			throw new AdminEmailNotFound(email+" email not found");
	}
	
	
}
