package com.project.apartment.exception;

public class WorkSpaceIdNotFoundException extends RuntimeException {

	public WorkSpaceIdNotFoundException(String message) {
		super(message);
	}

}
