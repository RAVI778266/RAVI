package com.project.apartment.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.apartment.dao.AddressDao;
import com.project.apartment.dao.AdminDao;
import com.project.apartment.dao.BuildingDao;
import com.project.apartment.dao.FloorDao;
import com.project.apartment.dao.ManagerDao;
import com.project.apartment.dto.Admin;
import com.project.apartment.dto.Building;
import com.project.apartment.dto.Floor;
import com.project.apartment.dto.Manager;
import com.project.apartment.exception.AdminIdNotFound;
import com.project.apartment.exception.BuildingNotFoundException;
import com.project.apartment.exception.ManagerIdNotFoundException;
import com.project.apartment.util.ResponseStructure;

@Service
public class BuildingService {

	@Autowired
	private BuildingDao buildingDao;
	@Autowired
	private AdminDao adminiDao;
	@Autowired
	private ManagerDao managerDao;
	@Autowired 
	private AddressDao addressDao;
	@Autowired
	private FloorDao floorDao;
//	@Autowired
//	private Building building;
//	Admini exist or not then only can ADD Buildings ;

	public ResponseEntity<ResponseStructure<Building>> saveBuilding(Building building, int Admini_id) {
		Admin admini = adminiDao.fetchAdmin(Admini_id);
		if (admini != null) {
			building.setAdmin(admini);
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.saveBuilding(building));
			structure.setMessage("Building saved successfully......");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure, HttpStatus.CREATED);

		} else {
			throw new AdminIdNotFound(Admini_id + "admmini is not available here ");
		}

	}
	
	public ResponseEntity<ResponseStructure<List<Building>>>FetchBuildingbyBuildingname(String Building_name) {
		List<Building> building = buildingDao.fetchBasedOnNames(Building_name);
		if (!building.isEmpty()) {
			ResponseStructure<List<Building>> structure = new ResponseStructure<List<Building>>();
			structure.setData(building);
			structure.setMessage("Building_deatils fetched successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);

		} else
			throw new BuildingNotFoundException(Building_name + "Building_name is not available here ");

	}

	public ResponseEntity<ResponseStructure<Building>> addManager(int building_id, int admin_id, int manager_id) {
		Admin admini = adminiDao.fetchAdmin(admin_id);
		if (admini != null) {
		Building building=buildingDao.fetchBuilding(building_id);
		if(building!=null && building.getManager()==null ) {
			Manager manager=managerDao.fetchManger(manager_id);
			if(manager!=null) {
			building.setManager(manager);
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.saveBuilding(building));
 			structure.setMessage("Building_deatils fetched successfully......");
			structure.setStatus(HttpStatus.ACCEPTED.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure,HttpStatus.ACCEPTED);
			}
			else
				throw new ManagerIdNotFoundException(manager_id+" Manager is not present");			
		}
		else
			throw new BuildingNotFoundException(building_id + " Building is not available here ");
		}
		else
			throw new AdminIdNotFound(admin_id + " admmini is not available here ");
	}

	public ResponseEntity<ResponseStructure<List<Building>>> fetchAll() {
		List<Building>  building=buildingDao.fetchAll();
		ResponseStructure<List<Building>> structure = new ResponseStructure<List<Building>>();
		structure.setData(building);
		structure.setMessage("Building_deatils fetched successfully......");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<List<Building>>> FetchBuildingbylocation(String location) {
		List<Building>  building=buildingDao.fetchBylocation(location);
		ResponseStructure<List<Building>> structure = new ResponseStructure<List<Building>>();
		structure.setData(building);
		structure.setMessage("Building_deatils fetched successfully......");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<Building>> FetchBuildingbyId(int id) {
		Building building=buildingDao.fetchBuilding(id);
		if(building!=null) {
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(building);
			structure.setMessage("Building_deatils fetched successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure,HttpStatus.FOUND);
		}
		else
			throw new BuildingNotFoundException(id + " Building is not available here ");
	}

	public ResponseEntity<ResponseStructure<Building>> updateBuilding(int id, Building building) {
		Building db=buildingDao.fetchBuilding(id);
		if(db!=null) {
			if(building.getBuilding_name()!=null) {
				db.setBuilding_name(building.getBuilding_name());
			}
			if(building.getRatings()!=0) {
				db.setRatings(building.getRatings());
			}
			if(building.getFloors()!=null) {
				db.setFloors(building.getFloors());
			}
			if(building.getAdmin()!=null) {
				db.setAdmin(building.getAdmin());
			}
//			else if(building.getAddress()!=null) {
//				db.setAddress(building.getAddress());
//			}
			db.setAddress(addressDao.saveAddress(building.getAddress(),db.getAddress().getId()));
			if(building.getManager()!=null) {
				db.setManager(building.getManager());
			}
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.saveBuilding(db));
			structure.setMessage("Building_deatils update successfully......");
			structure.setStatus(HttpStatus.CREATED.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure,HttpStatus.CREATED);
		}
		else
			throw new BuildingNotFoundException(id + " Building is not available here ");
	}

	public ResponseEntity<ResponseStructure<Building>> deleteBuilding(int id) {
		Building building=buildingDao.fetchBuilding(id);
		if(building!=null) {
//			floorDao.deleteFloor(building.getFloors());
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.deleteBuilding(building));
			structure.setMessage("Building_deatils delete successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure,HttpStatus.FOUND);
		}
		else
			throw new BuildingNotFoundException(id + " Building is not available here ");
	}

	public ResponseEntity<ResponseStructure<List<Building>>> fetchBuildingByadmin(int id) {
		Admin admin = adminiDao.fetchAdmin(id);
		if (admin != null) {
			ResponseStructure<List<Building>> structure = new ResponseStructure<>();
			structure.setData(buildingDao.fetchBuildingByadmin(admin));
			structure.setMessage("Building saved successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);

		} else {
			throw new AdminIdNotFound(id + "admmini is not available here ");
		}
	}

	public ResponseEntity<ResponseStructure<Building>> addFloor(int building_id, Floor floor) {
		Building building=buildingDao.fetchBuilding(building_id);
		if(building!=null) {
			List<Floor> f=building.getFloors();
			if(buildingDao.addfloor(f,floor)!=null) {
			f.add(floorDao.saveFloor(floor));					
			building.setFloors(f);
			ResponseStructure<Building> structure = new ResponseStructure<Building>();
			structure.setData(buildingDao.saveBuilding(building));
 			structure.setMessage("floor save successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Building>>(structure,HttpStatus.FOUND);
		}
			else 
				throw new BuildingNotFoundException("floor already add");
		}
		else
			throw new BuildingNotFoundException(building_id +"building id not found");
	}

	public ResponseEntity<ResponseStructure<List<Building>>> findCitys(String city) {
		List<Building>  building=buildingDao.findCitys(city);
		ResponseStructure<List<Building>> structure = new ResponseStructure<List<Building>>();
		structure.setData(building);
		structure.setMessage("Building_deatils fetched successfully......");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<List<String>>> findCity() {
		List<String>  building=buildingDao.findCity();
		ResponseStructure<List<String>> structure = new ResponseStructure<>();
		structure.setData(building);
		structure.setMessage("Building_deatils fetched successfully......");
		structure.setStatus(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<String>>>(structure, HttpStatus.FOUND);
	}

	/*public ResponseEntity<ResponseStructure<List<Building>>> findByAdminId(int id) {
		Admin admin = adminiDao.fetchAdmin(id);
		if(admin!=null) {
			List<Building>  building=buildingDao.adminAsNull(admin);
			ResponseStructure<List<Building>> structure = new ResponseStructure<List<Building>>();
			structure.setData(building);
			structure.setMessage("Building_deatils fetched successfully......");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Building>>>(structure, HttpStatus.FOUND);
		}
		else 
			throw new AdminIdNotFound(id + " admmini is not available here ");
	}*/
	
	
}