package com.project.apartment.dao;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.apartment.dto.Admin;
import com.project.apartment.repo.AdminRepo;

@Repository
public class AdminDao {
	@Autowired
	private AdminRepo adminRepo;
	 
	public Admin saveAdmin(Admin admin) {
		return adminRepo.save(admin);
	}

	public Admin fetchAdmin(int admin_id) {
		Optional<Admin> db= adminRepo.findById(admin_id);
		if(db.isPresent()) {
			return db.get();
		}
		return null;
	}

	public List<Admin> fetchByName(String name) {
		return adminRepo.fetchByName(name);
	}

	public Admin deleteAdmin(Admin db) {
		adminRepo.delete(db);
		return db;
	}

	public List<Admin> fetchByEmails(String email) {
		return adminRepo.fetchByEmails(email);
	}
	public Admin fetchByEmail(String email) {
		return adminRepo.fetchByEmail(email);
	}
	
	public List<Admin> fetchByDoorNo(String doorno) {
		return adminRepo.fetchByDoorNo(doorno);
	}

	public Admin adminLogin(String email, String password) {
		return adminRepo.adminLogin(email,password);
	}
}
