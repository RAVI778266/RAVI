package com.project.apartment.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.apartment.dto.Admin;

public interface AdminRepo extends JpaRepository<Admin,Integer>{
	@Query("select a from Admin a where a.name=?1")
	List<Admin> fetchByName(String name);
	@Query("select a from Admin a where a.email=?1")
	Admin fetchByEmail(String email);
	@Query("select a from Admin a where a.address.door_No=?1")
	List<Admin> fetchByDoorNo(String doorno);
	@Query("select a from Admin a where a.email=?1 and pwd=?2")
	Admin adminLogin(String email, String password);
	@Query("select a from Admin a where a.email=?1")
	List<Admin> fetchByEmails(String email);
	
}